#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>

#include "Escenario.h"

/*
Modos de proyección
*/

int Escenario::modoProyeccion = P_ORTOGONAL;
Punto* Escenario::puntito = new Punto();
Circulo* Escenario::circulito = new Circulo();

Escenario::Escenario() {

	//glutInitWindowSize(1420, 800);
	glutInitWindowSize(800, 800);
    glutInitWindowPosition(10,10);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("Escenario de dibujo");

    inicializar();
	glutReshapeFunc(redimensionar);
    glutDisplayFunc(dibujar);

}

void Escenario::inicializar(){
	glClearColor( 0.0, 0.0, 0.0, 0.0);	//Color Negro de fondo

    circulito->establecerRadio(20.0);
}

void Escenario::dibujar(){
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

    //Dibuja una tetera
    glColor3f(0, 1, 0);
	glPushMatrix();
        //Dibujar aquí
		//glutWireTeapot(50);
        puntito->dibujar();
        circulito->dibujar();
		pintarEjes();
	glPopMatrix();

    glFlush();
    glutSwapBuffers();

}

void Escenario::dibujarPlano(){
	int i;

	glColor3f(0.2901, 0.2901, 0.2901);
    for(i = -ESCALA; i <= ESCALA; i=i+10){
            //pinta las filas
            glBegin(GL_LINES);
                    glVertex3f(-ESCALA, 0, i);
                    glVertex3f(ESCALA, 0, i);
            glEnd();

            //pinta las columnas
            glBegin(GL_LINES);
                    glVertex3f(i, 0, -ESCALA);
                    glVertex3f(i, 0, ESCALA);
            glEnd();
    }

}

void Escenario::pintarEjes(){
 	//linea de X
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_LINES);
            glVertex3f(-ESCALA, 0, 0);
            glVertex3f(ESCALA, 0, 0);
    glEnd();

    //linea de Y
    glColor3f(0.0, 1.0, 0.0);
    glBegin(GL_LINES);
            glVertex3f(0, ESCALA, 0);
            glVertex3f(0, -ESCALA, 0);
    glEnd();

    //linea de Z
    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_LINES);
            glVertex3f(0, 0, ESCALA);
            glVertex3f(0, 0, -ESCALA);
    glEnd();
}

//aquí se define el modo de visualización
void Escenario::redimensionar(int w, int h){
	//Por ahora aquí se definirá el modo de proyección
	glViewport(0, 0, w, h);
	if (modoProyeccion == P_ORTOGONAL) {
		glMatrixMode( GL_PROJECTION );
		glOrtho( -ESCALA, ESCALA, -ESCALA, ESCALA, -ESCALA, ESCALA );
		glMatrixMode( GL_MODELVIEW );
		glLoadIdentity();
	} else {
		glMatrixMode(GL_PROJECTION);
		gluPerspective(40.0,(GLdouble)w/(GLdouble)h,0.5,20.0);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
	}

}


Escenario::~Escenario(){}
