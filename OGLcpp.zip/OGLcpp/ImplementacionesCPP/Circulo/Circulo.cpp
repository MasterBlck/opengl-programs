#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <iostream>
using std::cout;
using std::endl;

#include <cmath>
#include <cstdlib>
using std::rand;

#include "Circulo.h"

Circulo::Circulo(int x, int y, double r) : Punto(x, y) {
    this->radio = r;
    this->numVertices = 300;
}

void Circulo::establecerRadio( double r ){
    this->radio = r;
}

double Circulo::obtenerRadio() const {
    return this->radio;
}

double Circulo::obtenerDiametro() const {
    return this->radio * 2;
}
double Circulo::obtenerCircunferencia() const {
    return PI * obtenerRadio();
}

double Circulo::obtenerArea() const{
    return PI * obtenerRadio() * obtenerRadio();
}

void Circulo::dibujar() const {
    double t = 0;
    cout << "Centro del circulo: [ " << Punto::getX() << "," << Punto::getY() << " ] \n";
    
    glBegin(GL_POINTS);
        for(int i = 0; i < numVertices; ++i){
            glColor3f((float)rand()/(float)RAND_MAX,
                      (float)rand()/(float)RAND_MAX,
                      (float)rand()/(float)RAND_MAX);
            glVertex3f(Punto::getX() + radio * cos(t), Punto::getY() + radio * sin(t), 0.0);
            t += 2 * PI / numVertices;
        }
    glEnd();


}

Circulo::~Circulo (){}
