#ifndef ESCENARIO_H
#define ESCENARIO_H
#define ESCALA 100

#include "Punto.h"
#include "Circulo.h"

typedef enum{P_ORTOGONAL, P_PERSPECTIVA}Proyecciones;

class Escenario{
	private:
		static int modoProyeccion;
        static Punto *puntito;
        static Circulo *circulito;

	public:
		Escenario();
		static void dibujar();
		static void inicializar();
		static void dibujarPlano();
		static void pintarEjes();
		static void redimensionar(int w, int h);
		~Escenario();
};
#endif
