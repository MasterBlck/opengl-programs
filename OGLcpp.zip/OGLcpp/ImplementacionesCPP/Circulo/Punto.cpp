#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>

#include "Punto.h"

Punto::Punto(int x, int y){
    this->x = x;
    this->y = y;
}

void Punto::setX(int x) { this->x = x; }

int Punto::getX() const { return this->x; }

void Punto::setY( int y ) { this->y = y; }

int Punto::getY() const { return this->y; }

void Punto::dibujar() const{
    glPointSize(1.0);
    glBegin(GL_POINTS);
        glVertex3f(x, y, 0.0);
    glEnd();
}

Punto::~Punto() {}
