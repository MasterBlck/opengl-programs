#include "objeto.h"
/*
Objeto::Objeto() {
}
*/

void Objeto::tetera(GLfloat size){
	glutSolidTeapot(size);
}

