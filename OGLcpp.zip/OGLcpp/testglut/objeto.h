#ifndef OBJETO_H
#define OBJETO_H

#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>


class Objeto{
	public:
		//Objeto();
		void tetera(GLfloat size);
};

#endif
