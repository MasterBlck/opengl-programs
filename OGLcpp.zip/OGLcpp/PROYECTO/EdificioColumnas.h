#ifndef EDIFICIOCOLUMNAS_H
#define EDIFICIOCOLUMNAS_H

class EdificioColumnas{
    private:
        void dibujaPrisma(GLfloat wbase, GLfloat hbase, GLfloat wLado, GLfloat hLado);

    public:
        EdificioColumnas();
        void dibujar();
        void dibujaCilindro (int X, int Y, GLfloat LADOS);
        ~EdificioColumnas();

};
#endif
