#ifndef GUI_H
#define GUI_H
#include "Camara.h"

class gui{
	private:

	public:
		//static Camara* miCamara;

		//variables del movimiento del mouse
		static float alpha, beta;
		static int x0, y0;

		gui();
		static void onRaton(int boton, int estado, int x, int y);
		static void onMovimiento(int x, int y);

		static void controlTeclado(unsigned char key, int x, int y);
		static void funcionesEspeciales(int key, int x, int y);
		~gui();
};
#endif
