#ifndef PIRAMIDECIRCULAR_H
#define PIRAMIDECIRCULAR_H

class PiramideCircular{
    private:
        int numVertices;
        float R; // = 40.0; // Radius of circle.
        float X; // = 50.0; // X-coordinate of center of circle.
        float Y; // = 50.0; // Y-coordinate of center of circle.
        float Z;
        void base();
    public:
        PiramideCircular();
        void dibujar();
        ~PiramideCircular();

};
#endif
