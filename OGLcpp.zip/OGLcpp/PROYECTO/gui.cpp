#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include "gui.h"
#include "Camara.h"
#include <stdio.h>

float gui::alpha = 0;
float gui::beta = 0;
int gui::x0 = 0;
int gui::y0 = 0;
//Camara* gui::miCamara = new Camara();

gui::gui(){}

void gui::onRaton(int boton, int estado, int x, int y){
	if ( (boton == GLUT_LEFT_BUTTON) & (estado == GLUT_DOWN) ){
            x0 = x;
            y0 = y;
    }
}

void gui::onMovimiento(int x, int y){
	alpha = (alpha + (y - y0));
    beta = (beta + (x - x0));
    x0 = x; y0 = y;
    glutPostRedisplay();
}

void gui::controlTeclado(unsigned char key, int x, int y){
    switch(key){
        //cámara avanza hacia adelante
        case 'w':
        case 'W': //miCamara->moverAdelante( -0.1 );
                printf("Se mueve adelante\n");
                break;

        //cámara avanza hacia atrás
        case 's':
        case 'S': //miCamara->moverAdelante( 0.1 );
                printf("Se mueve atras\n");
                break;

        //cámara avanza hacia la derecha
        case 'a':
        case 'A':
                break;

        //cámara avanza hacia la izquierda
        case 'd':
        case 'D':
                break;
    }

    glutPostRedisplay();
}

void gui::funcionesEspeciales(int key, int x, int y){
    switch ( key ) {
        //Mostrar ayuda del programa
        case GLUT_KEY_F1:
                        break;

        //Cámara rota hacia arriba
        case GLUT_KEY_UP:
                        break;

        //Cámara rota hacia abajo
        case GLUT_KEY_DOWN:
                        break;

        //Cámara rota hacia la izquierda
        case GLUT_KEY_LEFT:
                        break;

        //Cámara rota hacia la izquierda
        case GLUT_KEY_RIGHT:
                        break;
    }
}

gui::~gui(){}
