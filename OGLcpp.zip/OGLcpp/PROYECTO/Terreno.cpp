#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <malloc.h>
#include <stdio.h>
#include "Terreno.h"
#include "Escenario.h"

Terreno::Terreno(){
    //carga las texturas para el terreno
/*
    glEnable(GL_TEXTURE_2D);//
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glGenTextures(2, &id_textura);
    glBindTexture(GL_TEXTURE_2D, id_textura);
    loadTextura("texturas/terreno0.bmp");
*/
}

void Terreno::dibujar(){
    glFrontFace(GL_CW);
    glColor3f(0.0, 1.0, 0.0);

    glBindTexture(GL_TEXTURE_2D, id_textura);
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
    glBegin(GL_POLYGON);
        glVertex3f(-10, 0, -10);
        glVertex3f(10, 0, -10);
        glVertex3f(10, 0, 10);
        glVertex3f(-10, 0, 10);
    glEnd();
}

int Terreno::loadTextura(char *filename){
    #define SAIR        {fclose(fp_archivo); return -1;}
    #define CTOI(C)     (*(int*)&C)

    GLubyte     *image;
    GLubyte     Header[0x54];
    GLuint      DataPos, imageSize;
    GLsizei     Width,Height;

    // Abre un archivo y efectua la lectura del encabezado del archivo BMP
    FILE * fp_archivo = fopen(filename,"rb");
    if (!fp_archivo)
        return -1;
    if (fread(Header,1,0x36,fp_archivo)!=0x36)
        SAIR;
    if (Header[0]!='B' || Header[1]!='M')
        SAIR;
    if (CTOI(Header[0x1E])!=0)
        SAIR;
    if (CTOI(Header[0x1C])!=24)
        SAIR;

    // Recupera los atributos de la altura y ancho de la imagen

    Width   = CTOI(Header[0x12]);
    Height  = CTOI(Header[0x16]);
    ( CTOI(Header[0x0A]) == 0 ) ? ( DataPos=0x36 ) : ( DataPos = CTOI(Header[0x0A]) );

    imageSize=Width*Height*3;

    // Llama a la imagen
    image = (GLubyte *) malloc ( imageSize );
    int retorno;
    retorno = fread(image,1,imageSize,fp_archivo);

    if (retorno != ((int)imageSize)){
        free (image);
        SAIR;
    }

    // Invierte los valores de R y B
    int t, i;

    for ( i = 0; i < ((int)imageSize); i += 3 ){
        t = image[i];
        image[i] = image[i+2];
        image[i+2] = t;
    }

    // Tratamiento de textura para OpenGL
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_MODULATE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_MODULATE);

    glTexEnvf ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE );

    // Manipulacion en memoria de la textura
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, Width, Height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

    fclose (fp_archivo);
    free (image);
    return 1;

}

Terreno::~Terreno(){}
