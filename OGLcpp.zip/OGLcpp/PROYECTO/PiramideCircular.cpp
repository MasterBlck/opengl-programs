#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <math.h>
#include "PiramideCircular.h"
#define PI 3.14159265358979324

PiramideCircular::PiramideCircular(){
    numVertices =  5;
    R = 40.0;
    X = 0.0;
    Y = 0.0;
    Z = 0.0;
}

void PiramideCircular::dibujar(){
    base();
}

void PiramideCircular::base(){
    float t = 0;
    glColor3f(0, 1, 0);

    glBegin(GL_POLYGON);
      for(int i = 0; i < numVertices; ++i){
         glVertex3f(X + R * cos(t), 0.0,Z + R * sin(t));
         t += 2 * PI / numVertices;
	  }
   glEnd();  
}

PiramideCircular::~PiramideCircular(){}
