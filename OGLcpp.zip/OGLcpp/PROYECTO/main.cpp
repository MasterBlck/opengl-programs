#include <GL/freeglut.h>
#include "Escenario.h"

int main(int argc, char *argv[]){

        glutInit(&argc, argv);
	      new Escenario();
        glutMainLoop();
        return 0;
}
