#ifndef CAMARA_H
#define CAMARA_H
#define PI 3.1415265359
#define PIdiv180 3.1415265359/180.0

#include <GL/freeglut.h>

struct SF3dVector  //Float 3d-vect, normally used
{
	GLfloat x,y,z;
};

struct SF2dVector
{
	GLfloat x,y;
};

class Camara{
    private:
        SF3dVector posicion;
	    SF3dVector viewDir;
        bool viewDirChanged;
	    GLfloat rotatedX, rotatedY, rotatedZ;

        void getViewDir ( void );
    public:
        Camara();       //Inicializa los valores de cámara en posición(0, 0, 0), target(0, 0, -1)
        void renderizar();
        void moverAdelante(GLfloat distancia);
        ~Camara();
};
#endif
