#include "Escenario.h"
#include "gui.h"
#include "Terreno.h"
#include "PiramideAzul.h"
#include "PiramideCircular.h"
#include "EdificioColumnas.h"
#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <stdio.h>

/*
Modos de proyección
*/
typedef enum{P_ORTOGONAL, P_PERSPECTIVA}Proyecciones;
int Escenario::modoProyeccion = P_ORTOGONAL;
Terreno* Escenario::terreno = new Terreno();
PiramideAzul* Escenario::piramide = new PiramideAzul();
PiramideCircular* Escenario::pCircular =  new PiramideCircular();
EdificioColumnas* Escenario::edif = new EdificioColumnas();

Escenario::Escenario() {

	//glutInitWindowSize(1420, 800);
	glutInitWindowSize(800, 800);
    glutInitWindowPosition(10,10);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("Escenario 3D");

    inicializar();
	glutReshapeFunc(redimensionar);
    glutDisplayFunc(dibujar);

	//funciones del mouse
	glutMouseFunc(gui::onRaton);
	glutMotionFunc(gui::onMovimiento);

	//funciones del teclado
	glutKeyboardFunc( gui::controlTeclado );
	glutSpecialFunc( gui::funcionesEspeciales );


}

void Escenario::inicializar(){
	glClearColor( 0.0, 0.0, 0.0, 0.0);	//Color Negro de fondo
/*
	glEnable(GL_TEXTURE_2D);//
    glPixelStorei(GL_UNPACK_ALIGNMENT,1);
    glGenTextures(2, &terreno->id_textura);
    glBindTexture(GL_TEXTURE_2D, terreno->id_textura);
    loadTextura("texturas/terreno0.bmp");
*/
}

void Escenario::dibujar(){
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

	//gui::miCamara->renderizar();

    //Dibuja una tetera
    glColor3f(0, 1, 0);
	glPushMatrix();
		//Rotar con respecto a x & y para obtener la perspectiva blender
		glRotatef(gui::alpha, 1.0f, 0.0f, 0.0f);
		glRotatef(gui::beta, 0.0f, 1.0f, 0.0f);

		//glutSolidTeapot(10);
		//glutWireTeapot(10);
		edif->dibujar();

		//pCircular->dibujar();
		glutWireTorus(0.3,1.0,8,16);
		glPushMatrix();
			glTranslatef(-70, 0, -80);
			piramide->dibujar();
		glPopMatrix();

		glutWireTorus(0.3,1.0,8,16);
		glPushMatrix();
			glTranslatef(70, 0, -80);
			piramide->dibujar();
		glPopMatrix();
		//terreno->dibujar();
		dibujarPlano();
		pintarEjes();
	glPopMatrix();

    glFlush();
    glutSwapBuffers();

}

void Escenario::dibujarPlano(){
	int i;

	glColor3f(0.2901, 0.2901, 0.2901);
    for(i = -ESCALA; i <= ESCALA; i=i+10){
            //pinta las filas
            glBegin(GL_LINES);
                    glVertex3f(-ESCALA, 0, i);
                    glVertex3f(ESCALA, 0, i);
            glEnd();

            //pinta las columnas
            glBegin(GL_LINES);
                    glVertex3f(i, 0, -ESCALA);
                    glVertex3f(i, 0, ESCALA);
            glEnd();
    }

}

void Escenario::pintarEjes(){
 	//linea de X
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_LINES);
            glVertex3f(-ESCALA, 0, 0);
            glVertex3f(ESCALA, 0, 0);
    glEnd();

    //linea de Y
    glColor3f(0.0, 1.0, 0.0);
    glBegin(GL_LINES);
            glVertex3f(0, ESCALA, 0);
            glVertex3f(0, -ESCALA, 0);
    glEnd();

    //linea de Z
    glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_LINES);
            glVertex3f(0, 0, ESCALA);
            glVertex3f(0, 0, -ESCALA);
    glEnd();
}

//aquí se define el modo de visualización
void Escenario::redimensionar(int w, int h){
	//Por ahora aquí se definirá el modo de proyección
	glViewport(0, 0, w, h);
	if (modoProyeccion == P_ORTOGONAL) {
		glMatrixMode( GL_PROJECTION );
		glOrtho( -ESCALA, ESCALA, -ESCALA, ESCALA, -ESCALA, ESCALA );
		glMatrixMode( GL_MODELVIEW );
		glLoadIdentity();
	} else {
		glMatrixMode(GL_PROJECTION);
		gluPerspective(40.0,(GLdouble)w/(GLdouble)h,0.5,20.0);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
	}

}

int Escenario::loadTextura(char *filename){
    #define SAIR        {fclose(fp_archivo); return -1;}
    #define CTOI(C)     (*(int*)&C)

    GLubyte     *image;
    GLubyte     Header[0x54];
    GLuint      DataPos, imageSize;
    GLsizei     Width,Height;

    // Abre un archivo y efectua la lectura del encabezado del archivo BMP
    FILE * fp_archivo = fopen(filename,"rb");
    if (!fp_archivo)
        return -1;
    if (fread(Header,1,0x36,fp_archivo)!=0x36)
        SAIR;
    if (Header[0]!='B' || Header[1]!='M')
        SAIR;
    if (CTOI(Header[0x1E])!=0)
        SAIR;
    if (CTOI(Header[0x1C])!=24)
        SAIR;

    // Recupera los atributos de la altura y ancho de la imagen

    Width   = CTOI(Header[0x12]);
    Height  = CTOI(Header[0x16]);
    ( CTOI(Header[0x0A]) == 0 ) ? ( DataPos=0x36 ) : ( DataPos = CTOI(Header[0x0A]) );

    imageSize=Width*Height*3;

    // Llama a la imagen
    image = (GLubyte *) malloc ( imageSize );
    int retorno;
    retorno = fread(image,1,imageSize,fp_archivo);

    if (retorno != ((int)imageSize)){
        free (image);
        SAIR;
    }

    // Invierte los valores de R y B
    int t, i;

    for ( i = 0; i < ((int)imageSize); i += 3 ){
        t = image[i];
        image[i] = image[i+2];
        image[i+2] = t;
    }

    // Tratamiento de textura para OpenGL
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_MODULATE);
    glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_MODULATE);

    glTexEnvf ( GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE );

    // Manipulacion en memoria de la textura
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, Width, Height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);

    fclose (fp_archivo);
    free (image);
    return 1;

}

Escenario::~Escenario(){}
