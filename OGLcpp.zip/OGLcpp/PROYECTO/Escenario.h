#ifndef ESCENARIO_H
#define ESCENARIO_H
#define ESCALA 100
#define ESCALA_X 50
#define ESCALA_Y 50
#define ESCALA_Z 50
#include "Terreno.h"
#include "PiramideAzul.h"
#include "PiramideCircular.h"
#include "EdificioColumnas.h"

class Escenario{
	private:
		static int modoProyeccion;
		static Terreno* terreno;
		static PiramideAzul* piramide;
		static PiramideCircular* pCircular;
		static EdificioColumnas* edif;
		void inicializarAtrib();
	public:
		Escenario();
		static void dibujar();
		static void inicializar();
		static void dibujarPlano();
		static void pintarEjes();
		static void redimensionar(int w, int h);
	    static int loadTextura(char *filename);
		~Escenario();
};
#endif
