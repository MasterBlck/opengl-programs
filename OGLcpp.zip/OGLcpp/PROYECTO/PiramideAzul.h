#ifndef PIRAMIDEAZUL_H
#define PIRAMIDEAZUL_H

class PiramideAzul{
    private:
        void trapecio();
    public:
        PiramideAzul();
        void dibujar();
        ~PiramideAzul();

};
#endif
