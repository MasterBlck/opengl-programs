#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include "PiramideAzul.h"

PiramideAzul::PiramideAzul(){}

void PiramideAzul::dibujar(){
    trapecio();
    /*
    for (int i = 0; i <= 3; i++) {
        glPushMatrix();
            glTranslatef(0, 10, 0);
            glScalef(10-i/10, 10-i/10, 10-i/10);
            trapecio();
        glPopMatrix();
    }
    */
    glPushMatrix();
        glTranslatef(0, 10, 0);
        glScalef(0.8, 0.8, 0.8);
        trapecio();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0, 20, 0);
        glScalef(0.6, 0.6, 0.6);
        trapecio();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0, 30, 0);
        glScalef(0.4, 0.4, 0.4);
        trapecio();
    glPopMatrix();
}

void PiramideAzul::trapecio(){
    GLfloat x = 0, y = 0, z = 0;

    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    //cara inferior
    glBegin(GL_POLYGON);
        glVertex3f(x - 20, y, z + 15);
        glVertex3f(x + 20, y, z + 15);
        glVertex3f(x + 20, y, z - 15);
        glVertex3f(x - 20, y, z - 15);
    glEnd();

    //cara superior
    /*
    glPushMatrix();
        glScalef(0.9, 0, 0.9);

        glBegin(GL_POLYGON);
            glVertex3f(x, y + 10, z);
            glVertex3f(x + 30, y + 10, z);
            glVertex3f(x + 30, y + 10, z - 20);
            glVertex3f(x, y + 10, z - 20);
        glEnd();
    glPopMatrix();
    */

    //cara frontal
    glBegin(GL_POLYGON);
        glVertex3f(x - 20, y, z + 15);
        glVertex3f(x + 20, y, z + 15);
        glVertex3f(x + 20 - 2.5, y + 10, z+15-2.5);
        glVertex3f(x - 20 + 2.5, y + 10, z+15-2.5);
    glEnd();

    //cara trasera
    glBegin(GL_POLYGON);
        glVertex3f(x - 20, y, z - 15);
        glVertex3f(x + 20, y, z - 15);
        glVertex3f(x + 20 - 2.5, y + 10, z-15+2.5);
        glVertex3f(x - 20 + 2.5, y + 10, z-15+2.5);
    glEnd();

    //cara lateral izquierda
    glBegin(GL_POLYGON);
        glVertex3f(x - 20, y, z + 15);
        glVertex3f(x - 20, y, z - 15);
        glVertex3f(x - 20 + 2.5, y + 10, z - 15 + 2.5);
        glVertex3f(x - 20 + 2.5, y + 10, z + 15 - 2.5);
    glEnd();

    //cara lateral derecha
    glBegin(GL_POLYGON);
        glVertex3f(x + 20, y, z + 15);
        glVertex3f(x + 20, y, z - 15);
        glVertex3f(x + 20 - 2.5, y + 10, z - 15 + 2.5);
        glVertex3f(x + 20 - 2.5, y + 10, z + 15 - 2.5);
    glEnd();

}
PiramideAzul::~PiramideAzul(){}
