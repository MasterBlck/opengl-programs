#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <math.h>
#include "Camara.h"

SF3dVector F3dVector ( GLfloat x, GLfloat y, GLfloat z ){
	SF3dVector tmp;
	tmp.x = x;
	tmp.y = y;
	tmp.z = z;
	return tmp;
}

void AddF3dVectorToVector ( SF3dVector *Dst, SF3dVector *V2)
{
	Dst->x += V2->x;
	Dst->y += V2->y;
	Dst->z += V2->z;
}

Camara::Camara(){
    //Inicializar los valores estándar
    posicion = F3dVector(0.0, 0.0, 0.0);    //Posición inicial de la cámara
    viewDir = F3dVector(0.0, 0.0, -1.0);    //vista al objetivo
    viewDirChanged = false;

    rotatedX = rotatedY =  rotatedZ = 0;
}

void Camara::renderizar(){
    //glRotatef(-rotatedX , 1.0, 0.0, 0.0);
    //glRotatef(-rotatedY , 0.0, 1.0, 0.0);
	//glRotatef(-rotatedZ , 0.0, 0.0, 1.0);
	glTranslatef( -posicion.x, -posicion.y, -posicion.z );
}

void Camara::moverAdelante(GLfloat distancia){
    if (viewDirChanged)
        getViewDir();

	SF3dVector MoveVector;
	MoveVector.x = viewDir.x * -distancia;
	MoveVector.y = viewDir.y * -distancia;
	MoveVector.z = viewDir.z * -distancia;
	AddF3dVectorToVector(&posicion, &MoveVector );
}

void Camara::getViewDir( void ){
    SF3dVector Step1, Step2;

	//Rotate around Y-axis:
	Step1.x = cos( (rotatedY + 90.0) * PIdiv180);
	Step1.z = -sin( (rotatedY + 90.0) * PIdiv180);

	//Rotate around X-axis:
	double cosX = cos (rotatedX * PIdiv180);
	Step2.x = Step1.x * cosX;
	Step2.z = Step1.z * cosX;
	Step2.y = sin(rotatedX * PIdiv180);
	//Rotation around Z-axis not yet implemented, so:

	viewDir = Step2;
}

Camara::~Camara(){}
