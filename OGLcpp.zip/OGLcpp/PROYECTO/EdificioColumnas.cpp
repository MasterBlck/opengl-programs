#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <math.h>
#include "EdificioColumnas.h"
#define GL_PI 3.14159265358979324

EdificioColumnas::EdificioColumnas(){}
void EdificioColumnas::dibujar(){
    //dibujaCilindro(0, 0, 100);
    GLfloat x = 0, y = 0, z = 0;

    for (int i = 1; i <= 5; i++) {
        glBegin(GL_POLYGON);
            //glVertex3f( x - hLado/2, );
            //glPushMatrix();
                //glTranslatef(i*5,0, 0);
                dibujaCilindro(i*15, 0, 90);
            //glPopMatrix();

        glEnd();
    }

    //dibujaCilindro(0, 0, 90);


}

void EdificioColumnas::dibujaPrisma(GLfloat wbase, GLfloat hbase, GLfloat wLado, GLfloat hLado){
    GLfloat x = 0, y = 0, z = 0;

    glBegin(GL_POLYGON);
        //glVertex3f( x - hLado/2, );
    glEnd();
}

void EdificioColumnas::dibujaCilindro (int X, int Y, GLfloat LADOS)
{
	GLfloat x, y, z, angle;
	GLfloat radio;
	int Contador = 0;

	GLfloat Puntos1[100][3];
	GLfloat Puntos2[100][3];


	glBegin(GL_POLYGON);
    	//glColor3f(1.0,0.0,1.0);
    	z = 5;
    	radio = 5;
    	Contador = 0;
    	//printf ("n Puntos Primer Poligono ");
    	for(angle = 0.0f; angle <= (2.0f*GL_PI); angle += (2.0f*GL_PI)/LADOS)
    	{
    		Puntos1[Contador][0] = radio*sin(angle)+X;
    		Puntos1[Contador][2] = radio*cos(angle)+Y;
    		Puntos1[Contador][1] = z;
                    //glTexCoord2f((0.5*sin(angle)+0.5),(0.5*cos(angle)+0.5));
    		glVertex3f(Puntos1[Contador][0], Puntos1[Contador][1], Puntos1[Contador][2]);
     		Contador++;
    	}
	glEnd();

	//printf ("n Puntos Segundo Poligono ");
	glBegin(GL_POLYGON);
    //	glColor3f(1.0,0.0,0.0);
    	z = -5;
    	radio = 5;
    	Contador = 0;
    	for(angle = 0.0f; angle <= (2.0f*GL_PI); angle += (2.0f*GL_PI)/LADOS)
    	{
    		Puntos2[Contador][0] = radio*sin(angle)+X;
    		Puntos2[Contador][2] = radio*cos(angle)+Y;
    		Puntos2[Contador][1] = z;
         //glTexCoord2f((0.5*sin(angle)+0.5),(0.5*cos(angle)+0.5));
    		glVertex3f(Puntos2[Contador][0], Puntos2[Contador][1], Puntos2[Contador][2]);
    		Contador++;

    	}
	glEnd();

	glColor3f(1.0f, 1.0f, 1.0f);

	GLfloat IncrementoLado = 1.0/LADOS;
	GLfloat OffsetLado = 0.0;
	GLfloat SigLado = IncrementoLado;

	for (Contador = 0; Contador<LADOS; Contador++)
	{
		glBegin(GL_POLYGON);
		//glColor3f(1.0,1.0,1.0/(Contador+1));
			int Temporal = 0;
			if (Contador==(int) (LADOS-1))
				Temporal = 0;
			else
				Temporal = Contador+1;

			glVertex3f(Puntos1[Contador][0], Puntos1[Contador][1], Puntos1[Contador][2]);

			glVertex3f(Puntos1[Temporal][0], Puntos1[Temporal][1], Puntos1[Temporal][2]);

			glVertex3f(Puntos2[Temporal][0], Puntos2[Temporal][1], Puntos2[Temporal][2]);

			glVertex3f(Puntos2[Contador][0], Puntos2[Contador][1], Puntos2[Contador][2]);
		glEnd();
			OffsetLado = SigLado;
			SigLado += IncrementoLado;
	}
}

EdificioColumnas::~EdificioColumnas(){}
