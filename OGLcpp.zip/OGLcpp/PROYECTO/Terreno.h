#ifndef CAMARA_H
#define CAMARA_H
#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>

class Terreno{
    private:
        int loadTextura(char *filename);

    public:
        GLuint id_textura;
        Terreno();
        void dibujar();
        ~Terreno();
};
#endif
