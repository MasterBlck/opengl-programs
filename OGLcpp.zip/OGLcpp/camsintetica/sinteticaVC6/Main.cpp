#include <windows.h>
#include <GL/glut.h>
#include <iostream>
#include "CWin.h"
#include "CCamera.h"
#include "CImage.h"

#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glut32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"glaux.lib")

#define ID_TEXTURE 0

using namespace std;

CWin Win;
CImage Image;
CCamera Camera(2.0f,1.0f,-6.0f,
			   0.0f,1.0f,0.0f,
			   0.0f,1.0f,0.0f);
unsigned int Texture[1];

void Key(unsigned char Tecla,int x,int y);
void Render();
void Terrain();
void Special(int iKey, int x, int y);
void InitOpenGL();

int main(int argc, char **argv)
{
 Win.InitWin(argc,argv);
 Win.CreateWin(640,480,"Ejemplo de una camara",false);
 InitOpenGL();
 glutKeyboardFunc(Key);
 glutDisplayFunc(Render);
 glutSpecialFunc(Special);
 glutMainLoop();
 return 0;
}


void Special(int iKey, int x, int y)
{
 switch(iKey){
    case GLUT_KEY_UP:
		       Camera.Move(MOVE_FORWARD,0.4f);
		       break;
	 case GLUT_KEY_DOWN:
		       Camera.Move(MOVE_BACKWARD,0.4f);
		       break;
     case GLUT_KEY_RIGHT:
		       Camera.Rotate(-0.025f, 0.0f, 1.0f, 0.0f);
	           break;
     case GLUT_KEY_LEFT:
		       Camera.Rotate(0.025f, 0.0f, 1.0f, 0.0f);
	           break;
 }
 glutPostRedisplay();
}
void Key(unsigned char Tecla,int x, int y)
{
    switch(Tecla){
	 case 27:  exit (0);
		       break;
	}
}

void InitOpenGL()
{
	cout << "Oprime <Esc> para salir" << endl;
    cout << "<Flecha de arriba> se mueve hacia adelante." << endl;
	cout << "<Flecha de abajo> se mueve hacia abajo." << endl;
    cout << "<Flecha hacia la derecha> rota hacia la derecha" << endl;
	cout << "<Flecha hacia la izquierda> rota hacia la izquierda" << endl;

    if(!Image.CreateTexture(Texture,ID_TEXTURE,"textura.bmp")){
		cerr << "Error al cargar la textura" << endl;
		exit(1);
	}
	glClearColor(0.4f, 0.4f, 1.0f, 0.0f);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_TEXTURE_2D);
	glEnable(GL_DEPTH_TEST);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
}

void Terrain()
{
   int x, z = 0;
   Camera.SetLook();

   glBindTexture(GL_TEXTURE_2D,Texture[ID_TEXTURE]);
   for(int i = 0; i < 10; i++){
     for(int j = 0; j < 10; j++){
               glBegin(GL_QUADS);
                  glTexCoord2f(0.0, 0.0); glVertex3f(15.0f + x, -0.01f, 15.0f + z);
                  glTexCoord2f(1.0, 0.0); glVertex3f(10.0f + x, -0.01f, 15.0f + z);
                  glTexCoord2f(1.0, 1.0); glVertex3f(10.0f + x, -0.01f, 10.0f + z);
                  glTexCoord2f(0.0, 1.0); glVertex3f(15.0f + x, -0.01f, 10.0f + z);
               glEnd();
         x += -5;
     }
    x = 0;
    z += -5;
 }
}

void Render()
{
  Win.ClearWin();
  Terrain();
  glutSwapBuffers();
}
