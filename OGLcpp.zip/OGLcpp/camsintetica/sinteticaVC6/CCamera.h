#ifndef __CCAMERA_H
#define __CCAMERA_H

#include "CVector.h"

enum MOVE_CAMERA{ MOVE_FORWARD=1, 
                  MOVE_BACKWARD 
                };

class CCamera{
 public:
	 CCamera();
	 CCamera(float xPosition,float yPosition,float zPosition,
		     float xView,    float yView,    float zView,
			 float xUp=0.0f,      float yUp=1.0f,      float zUp=0.0f);
	
	 void Move(int Direction,float fSpeed);
	 void Rotate(float fAngle,float X,float Y,float Z);
	 void SetLook();
	 CVector GetPosition(){ return Position; }
	 CVector GetView()    { return View; }
	 CVector GetUp()      { return Up;   }

private:	
	void MoveCamera(float fSpeed);	
	CVector Position;
	CVector View;
	CVector Up;
};

#endif