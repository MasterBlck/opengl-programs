#ifndef __CIMAGE_H
#define __CIMAGE_H

struct Image
{
    int numComponents;          
    int sizeX;              
    int sizeY;              
    unsigned char *data;    
};

class CImage{
private:
 Image *pImage;
 Image *LoadBMP(const char *strFileName);
public:
 bool CreateTexture(unsigned int *textureArray,int textureID,const char *strFileName);
 
};

#endif