#ifndef __CWIN_H
#define __CWIN_H

class CWin{
 private:
   char *strTitle;
   int Height,Width;
 public:
   void InitWin(int argc,char **argv);
   void CreateWin(int iWidth,int iHeight,const char *SetCaption,bool bFullScreen);
   void GetSizeWin(int &iWidth,int &iHeight);
   void ClearWin();
   char *GetCaption();
   void ChangeSizeWin(int iWidth,int iHeight);
   void SetCaption(const char *strText);
};

#endif