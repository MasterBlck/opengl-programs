#include "CVector.h"
#include <math.h>

float CVector::GetVectorLenght(CVector Vector)
{
 return (float)sqrt((Vector.x*Vector.x)+(Vector.y*Vector.y)+(Vector.z*Vector.z));
}

CVector CVector::Add(CVector Vector1,CVector Vector2)
{
 CVector vResult;  
 vResult.x = Vector1.x + Vector2.x;
 vResult.y = Vector1.y + Vector2.y;  
 vResult.z = Vector1.z + Vector2.z;
 return vResult;
}

CVector CVector::Subtract(CVector vVector1,CVector vVector2)
{
 CVector vResult;   
 vResult.x = vVector1.x - vVector2.x;
 vResult.y = vVector1.y - vVector2.y;
 vResult.z = vVector1.z - vVector2.z; 
 return vResult;
}

float CVector::Dot(CVector vVector1, CVector vVector2) 
{
 return ( (vVector1.x * vVector2.x) + (vVector1.y * vVector2.y) + (vVector1.z * vVector2.z) );
}

CVector CVector::Cross(CVector vVector1, CVector vVector2)
{
 CVector vNormal;                                                                                                                                                               
 vNormal.x = ((vVector1.y * vVector2.z) - (vVector1.z * vVector2.y));                                                                                            
 vNormal.y = ((vVector1.z * vVector2.x) - (vVector1.x * vVector2.z));                                                                                                    
 vNormal.z = ((vVector1.x * vVector2.y) - (vVector1.y * vVector2.x));
 return vNormal;                                                                          
}

CVector CVector::Normalize(CVector vNormal)
{
 float fLength;
 fLength=GetVectorLenght(vNormal);                  
 vNormal.x /= fLength;                                                           
 vNormal.y /= fLength;                                                           
 vNormal.z /= fLength;                                                   
 return vNormal;                                                                         
}

