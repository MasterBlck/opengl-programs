#include <windows.h>
#include "CCamera.h"
#include <GL\glut.h>
#include <math.h>

CCamera::CCamera()
{
 Position.x=0.0f;
 Position.y=0.0f;
 Position.z=0.0f;

 View.x=0.0f;
 View.y=0.0f;
 View.z=0.0f;

 Up.x=0.0f;
 Up.y=1.0f;
 Up.z=0.0f;
}


CCamera::CCamera(float xPosition,float yPosition,float zPosition,
				 float xView,float yView,float zView,
				 float xUp,float yUp,float zUp)
{
	Position.x=xPosition;
	Position.y=yPosition;
	Position.z=zPosition;

	View.x=xView;
	View.y=yView;
	View.z=zView;

	Up.x=xUp;
	Up.y=yUp;
	Up.z=zUp;
}

void CCamera::SetLook()
{
	gluLookAt(Position.x,Position.y,Position.z,
		      View.x,View.y,View.z,
		      Up.x,Up.y,Up.z);
}

void CCamera::MoveCamera(float fSpeed)
{
	CVector Direction;
	CVector vVector;

	Direction.x=0.0f;
	Direction.y=0.0f;
	Direction.z=0.0f;

	Direction.x=View.x-Position.x;
	Direction.y=View.y-Position.y;
	Direction.z=View.z-Position.z;

	Direction=vVector.Normalize(Direction);

	Position.x += Direction.x * fSpeed;
	Position.y += Direction.y * fSpeed;
	Position.z += Direction.z * fSpeed;

	View.x += Direction.x * fSpeed;
	View.y += Direction.y * fSpeed;
	View.z += Direction.z * fSpeed;
}

void CCamera::Move(int iDirection,float fSpeed)
{
 if(iDirection==MOVE_FORWARD)
  MoveCamera(fSpeed);
 if(iDirection==MOVE_BACKWARD)
  MoveCamera(-fSpeed);
}

void CCamera::Rotate(float fAngle, float x, float y, float z)
{
	CVector vNewDirection;
	CVector vDirection;

    vNewDirection.x=0.0f;
	vNewDirection.y=0.0f;
	vNewDirection.z=0.0f;

    vDirection.x=0.0f;
	vDirection.y=0.0f;
	vDirection.z=0.0f;

	vDirection.x = View.x - Position.x;
	vDirection.y = View.y - Position.y;
	vDirection.z = View.z - Position.z;

	float cosTheta = static_cast<float>(cos(fAngle));
	float sinTheta = static_cast<float>(sin(fAngle));

	vNewDirection.x  = (cosTheta + (1 - cosTheta) * x * x)		* vDirection.x;
	vNewDirection.x += ((1 - cosTheta) * x * y - z * sinTheta)	* vDirection.y;
	vNewDirection.x += ((1 - cosTheta) * x * z + y * sinTheta)	* vDirection.z;

	vNewDirection.y  = ((1 - cosTheta) * x * y + z * sinTheta)	* vDirection.x;
	vNewDirection.y += (cosTheta + (1 - cosTheta) * y * y)		* vDirection.y;
	vNewDirection.y += ((1 - cosTheta) * y * z - x * sinTheta)	* vDirection.z;

	vNewDirection.z  = ((1 - cosTheta) * x * z - y * sinTheta)	* vDirection.x;
	vNewDirection.z += ((1 - cosTheta) * y * z + x * sinTheta)	* vDirection.y;
	vNewDirection.z += (cosTheta + (1 - cosTheta) * z * z)		* vDirection.z;

	View.x = Position.x + vNewDirection.x;
	View.y = Position.y + vNewDirection.y;
	View.z = Position.z + vNewDirection.z;
}
