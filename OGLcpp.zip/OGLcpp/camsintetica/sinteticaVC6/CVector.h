#ifndef __CVECTOR_H
#define __CVECTOR_H

class CVector{
 public:
  float x,y,z;
  CVector(){  }
  CVector(float X,float Y,float Z){
   x=X;
   y=Y;
   z=Z;
  }
  CVector Add(CVector Vector1,CVector Vector2);
  CVector Cross(CVector Vector1,CVector Vector2);
  CVector Subtract(CVector Vector1,CVector Vector2);
  CVector Normalize(CVector Vector);
  float   Dot(CVector Vector1, CVector Vector2);
  float   GetVectorLenght(CVector Vector);
};

#endif
