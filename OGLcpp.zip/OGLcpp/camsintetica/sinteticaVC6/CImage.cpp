#include <gl/glaux.h>
#include <iostream>
#include <fstream>
#include "CImage.h"

using namespace std;

//Carga una imagen BMP a 8, 16, 24  bits de color
//Retorna los numeros de componenes del color
//el ancho y el alto de la imagen y un apuntador a la imagen
Image *CImage::LoadBMP(const char *strFileName)
{
	ifstream f;
	AUX_RGBImageRec *pBitmap = NULL;

    //Abrimos el archivo a cargar, si existe
	f.open(strFileName,ios::binary);
	//si existe algun error procesamos el error y devuelve NULL
	if(f.fail()){
        cerr << "Carga el archivo "<< strFileName << "<Fail>" << endl;
        return NULL;
	}
	//Cargamos los datos de la imagen bmp
	//La funcion auxDIBImageLoad nos devuelve un apuntador
	//a una estructura que contendra la informacion necesaria
	//para guardarla en nuestra estructura
	pBitmap = auxDIBImageLoad(strFileName);
	//Asignamos memoria
	pImage = new Image;
	pImage->numComponents = 3;      //Numero de componentes de color 3=RGB
	pImage->sizeX = pBitmap->sizeX; //El ancho de la imagen
	pImage->sizeY = pBitmap->sizeY; //El alto de la imagen
	pImage->data  = pBitmap->data;  //apuntador a la imagen
	//Libera memoria asignada
	delete [] pBitmap;
	//cierra el archivo
	f.close();
	return pImage;
}


bool CImage::CreateTexture(unsigned int *textureArray,int textureID,const char *strFileName)
{
	Image *pImage = NULL;
     //Si no se especifica el nombre de la textura
    //se procesa el error y devuelve false
	if(!strFileName){
		cerr << "Nombre del archivo <Fail>" << endl;
		return false;
	}
	//Buscamos si el nombre de la textura
	//es una imagen .bmp si es asi entonces
	//la cargamos
	if(strstr(strFileName, ".bmp")){
     pImage = LoadBMP(strFileName);
	}

	else{
	 cerr << "Imagen no valida <Fail>" <<	endl;
	 return false;
	}
	//Si no se puede cargar la imagen
	 //procesamos el error y devolvemos false
	 if(!pImage){
	  cerr << "Cargar la imagen <Fail>" <<	endl;
	  return false;
	 }
     glGenTextures(1, &textureArray[textureID]);
	 glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
     glBindTexture(GL_TEXTURE_2D, textureArray[textureID]);
     glTexImage2D(GL_TEXTURE_2D, 0,pImage->numComponents, pImage->sizeX, pImage->sizeY, 0, GL_RGB, GL_UNSIGNED_BYTE, pImage->data);
	 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
	 glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);

	 //Liberamos memoria que
	 //habia sido asignada para la imagen
	 if(pImage){
        if (pImage->data){
            free(pImage->data);
        }
      free(pImage);
     }

 return true;
}

