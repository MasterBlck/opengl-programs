#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <string.h>
#include <assert.h>
#include <stdarg.h>
#include <stdio.h>
#include "CWin.h"

//incializa glut
void CWin::InitWin(int argc,char **argv)
{
 glutInit(&argc,argv);
}

//Crea nuestra ventana
void CWin::CreateWin(int iWidth,int iHeight,const char *Title,bool bFullScreen)
{
 glutInitDisplayMode(GLUT_RGB | GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
 if(bFullScreen){
  glutInitWindowPosition(100,100);
  glutInitWindowSize(iWidth,iHeight);
  glutCreateWindow(Title);
  glutFullScreen();
  ChangeSizeWin(iWidth,iHeight);
  strTitle=new char[strlen(Title)+1];
  assert(strTitle!=0);
  strcpy(strTitle,Title);
  Width=iWidth;
  Height=iHeight;
 }
 else{
  glutInitWindowPosition(100,100);
  glutInitWindowSize(iWidth,iHeight);
  glutCreateWindow(Title);
  ChangeSizeWin(iWidth,iHeight);
  strTitle=new char[strlen(Title)+1];
  assert(strTitle!=0);
  strcpy(strTitle,Title);
  Width=iWidth;
  Height=iHeight;
 }

}


//Devuelve el titulo
char *CWin::GetCaption()
{
 return strTitle;
}

//Devuelve el tama�o de la ventana
void CWin::GetSizeWin(int &iWidth,int &iHeight)
{
 iWidth =Width;
 iHeight=Height;
}

//Limpia el buffer de profundidad
void CWin::ClearWin()
{
 glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
 glLoadIdentity();
}


//Cambia el tama�o de la ventana
void CWin::ChangeSizeWin(int iWidth,int iHeight)
{

    if (iHeight==0){ //Previene una division entre cero
        iHeight=1;
    }
    glViewport(0,0,iWidth,iHeight);     //Ajusta la vista a las dimensiones de la ventana
    glMatrixMode(GL_PROJECTION);        //Activa la matriz de proyeccion
    glLoadIdentity();                   //Reinicia el sistema de coordenadas
    gluPerspective(45.0f,(GLfloat)iWidth/(GLfloat)iHeight, 1.0f ,1000.0f);
    glMatrixMode(GL_MODELVIEW);         //Activa la matriz del modelador
    glLoadIdentity();                   //Reinicia el sistema de coordenadas
}

void CWin::SetCaption(const char *strText)
{
 glutSetWindowTitle(strText);    //Asignamos el titulo a la ventana
}
