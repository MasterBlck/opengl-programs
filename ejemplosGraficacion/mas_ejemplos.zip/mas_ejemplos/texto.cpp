// Ejemplo de la utilizaci�n de texto en OpenGL
#include <windows.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#define PI 3.141592654

static char label[100];

void inline drawString (char *s)
{
	unsigned int i;
	for (i=0; i<strlen(s); i++)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, s[i]);
}

void init(void)
{
	glClearColor (0.0,0.0,0.0,1.0);
}

void reshape(int w, int h)
{
	 if (!h)
		 return;
	 glViewport(0, 0,  (GLsizei) w, (GLsizei) h);
     glMatrixMode(GL_PROJECTION);   // Activamos la matriz de proyeccion
     glLoadIdentity();				// "limpiamos" con la matriz identidad.
     gluOrtho2D(0, w, 0, h);        // usamos proyeccion ortogonal
     glScalef(1, -1, 1);            // se invierte el eje y, es decir, hacia abajo es positivo
     glTranslatef(0, -h, 0);        // se mueve el origen de la esquina inferior izq
									// hacia la esquina superior del mismo lado

     glMatrixMode(GL_MODELVIEW);    // activamos la matriz del modelo de vision
     glLoadIdentity();              // limpiamos la matriz
}


void display(void)
{
	int i;
    double angulo;
    float x,y;
    char *nombre="angulo    sin(angulo)";

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode( GL_MODELVIEW_MATRIX );
    glLoadIdentity();

    glColor3f(0.1, 1.0, 0.1);
    sprintf(label,"%s", nombre);
    glRasterPos2f(95, 20);
    drawString (label);

    glColor3f(1.0, 1.0, 1.0);
    angulo=0.0;
    x=100;
    y=35;
    for (i=0; i<19; i++)
	{
		sprintf (label, "%4.2f      %4.5f",angulo, sin(angulo*PI/180));
	    glRasterPos2f (x,y);
	    drawString (label);
	    angulo+=10;
	    y=y+15;
	}
    glFlush();
}


void keyboard(unsigned char key, int x, int y)
{
	switch (key)
   {
		case 27: exit(0);
             break;
   }
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (300, 320);
    glutInitWindowPosition (0, 0);
    glutCreateWindow ("Texto en OpenGL");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutMainLoop();

    return 0;
}

