#include <windows.h>
#include <gl/glut.h>
#include "GLTools.h"
#include "VectorMath.c"

static GLfloat xRot = 0.0;
static GLfloat yRot = 0.0;
static GLfloat xTrans = 0.0;
static GLfloat yTrans = 0.0;
static GLfloat zTrans = 0.0;

void cambia(int w,int h){
	GLfloat fAspecto;

	if(h==0)
		h = 1;

	glViewport(0,0,w,h);

	fAspecto = (GLfloat) w/(GLfloat)h;
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-80, 80., -80., 80., -80., 80.);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

// Crea la cabeza del tornillo
void cabeza(void)
{
	float x,y,angulo;                    // Calcula posiciones
    float altura = 25.0f;               // Grosor de la cabeza
    float diametro = 30.0f;             // Diametro de la cabeza
    GLTVector3 vNormal,vCorners[4];     // Almacenamiento de vertices y normales
    float paso = (3.1415f/3.0f);        // paso = 1/6 del circulo = hexagono

    // fija el color del material para la cabeza
    glColor3f(0.7f, 0.7f, 0.7f);

    // Inicia un nuevo triangulo para cubrir la parte superior
    glFrontFace(GL_CCW);
    glBegin(GL_TRIANGLE_FAN);
	    // Todas las normales para la parte posterior apuntan hacia el eje Z
        glNormal3f(0.0f, 0.0f, 1.0f);
        // El centro de fan esta en el origen
        glVertex3f(0.0f, 0.0f, altura/2.0f);
        // Divide el circulo en 6 secciones

        // Primer y ultimo vertice cercanos a fan
        glVertex3f(0.0f, diametro, altura/2.0f);
        for(angulo = (2.0f*3.1415f)-paso; angulo >= 0; angulo -= paso)
			{
            // Calcula las posiciones x,y del siguiente vertice
            x = diametro*(float)sin(angulo);
            y = diametro*(float)cos(angulo);

            // Especifica el siguiente vertice al triangulo Fan
            glVertex3f(x, y, altura/2.0f);
            }

        // Ultimo vertice cercano al Fan
        glVertex3f(0.0f, diametro, altura/2.0f);
	glEnd();

    // Inicia un nuevo triangulo para cubrir la parte inferior
    glBegin(GL_TRIANGLE_FAN);
        // Las normales para los puntos inferiores apuntan hacia el eje Z negativo
        glNormal3f(0.0f, 0.0f, -1.0f);
        // El centro de Fan esta en el origen
        glVertex3f(0.0f, 0.0f, -altura/2.0f);

        // Divide el circulo en 6 secciones

        for(angulo = 0.0f; angulo < (2.0f*3.1415f); angulo += paso)
            {
            // Calcula las posiciones x,y del siguiente vertice
            x = diametro*(float)sin(angulo);
            y = diametro*(float)cos(angulo);

            // Especifica el siguiente vertice para el triangulo fan
            glVertex3f(x, y, -altura/2.0f);
            }

        // Ultimo vertice, usadao para cerrar el fan
        glVertex3f(0.0f, diametro, -altura/2.0f);

    glEnd();

    // Construye los lados de la figura (dos lados). Cada face consiste de dos
    // triangulos arreglados para formar un cuadriatero
    glBegin(GL_QUADS);
        // dibuja los lados
        for(angulo = 0.0f; angulo < (2.0f*3.1415f); angulo += paso)
            {
            // Calcula las posiciones x,y del siguiente punto hex
            x = diametro*(float)sin(angulo);
            y = diametro*(float)cos(angulo);

            // Inicia la parte inferior de la cabeza
            vCorners[0][0] = x;
            vCorners[0][1] = y;
            vCorners[0][2] = -altura/2.0f;

            vCorners[1][0] = x;
            vCorners[1][1] = y;
            vCorners[1][2] = altura/2.0f;

            // Calcula el siguiente punto hex
            x = diametro*(float)sin(angulo+paso);
            y = diametro*(float)cos(angulo+paso);

            if(angulo+paso < 3.1415*2.0)
                {
                vCorners[2][0] = x;
                vCorners[2][1] = y;
                vCorners[2][2] = altura/2.0f;

                vCorners[3][0] = x;
                vCorners[3][1] = y;
                vCorners[3][2] = -altura/2.0f;
                }
            else
                {
                vCorners[2][0] = 0.0f;
                vCorners[2][1] = diametro;
                vCorners[2][2] = altura/2.0f;

                vCorners[3][0] = 0.0f;
                vCorners[3][1] = diametro;
                vCorners[3][2] = -altura/2.0f;
                }

            // Los vectores normal para la cara entera, todos los puntos tienen
            // la misma direccion
            gltGetNormalVector(vCorners[0], vCorners[1], vCorners[2], vNormal);
            glNormal3fv(vNormal);

            // Especifica cada quad separadamente para ligar el siguiente
            // a cada otro
            glVertex3fv(vCorners[0]);
            glVertex3fv(vCorners[1]);
            glVertex3fv(vCorners[2]);
            glVertex3fv(vCorners[3]);
            }
    glEnd();
}

// Crea la barra del tornillo

void barra(void)
{
	float x,z,angulo;                    // usado para calcular la pared del cilindro
    float altura = 75.0f;               // altura del cilindro
    float diametro = 20.0f;             // diametro del cilindro
    GLTVector3 vNormal,vCorners[2];     // Almacenamiento para los calculos de vertices
    float paso = (3.1415f/50.0f);       // Aproxima la padred del cilindro con
                                        // 100 segmentos planos.

    // fija el color del material para la cabeza del tornillo
    glColor3f(0.7f, 0.7f, 0.7f);

    // Primero ensambla la pared como 100 cuadrilateros formada
    // al colocar Quands juntos
    glFrontFace(GL_CCW);
    glBegin(GL_QUAD_STRIP);
        // Dibuja los lados
        for(angulo = (2.0f*3.1415f); angulo > 0.0f; angulo -= paso)
            {
            // Calcula las posiciones x,y del primer vertice
            x = diametro*(float)sin(angulo);
            z = diametro*(float)cos(angulo);

           vCorners[0][0] = x;
           vCorners[0][1] = -altura/2.0f;
           vCorners[0][2] = z;

           vCorners[1][0] = x;
           vCorners[1][1] = altura/2.0f;
           vCorners[1][2] = z;

           vNormal[0] = vCorners[1][0];
           vNormal[1] = 0.0f;
           vNormal[2] = vCorners[1][2];

           gltNormalizeVector(vNormal);
           glNormal3fv(vNormal);
           glVertex3fv(vCorners[0]);
           glVertex3fv(vCorners[1]);
           }

        // Se asegura que no hay huecos
        glVertex3f(diametro*(float)sin(2.0f*3.1415f), -altura/2.0f,
                                       diametro*(float)cos(2.0f*3.1415f));
        glVertex3f(diametro*(float)sin(2.0f*3.1415f), altura/2.0f,
                                       diametro*(float)cos(2.0f*3.1415f));
    glEnd();

    // Dibuja un nuevo triangulo para cubrir la parte inferior
    glBegin(GL_TRIANGLE_FAN);
        // Normal points down the Y axis
        glNormal3f(0.0f, -1.0f, 0.0f);
        // El centro de fan esta en el origen
        glVertex3f(0.0f, -altura/2.0f, 0.0f);

        for(angulo = (2.0f*3.1415f); angulo > 0.0f; angulo -= paso)
            {
            // Calcula la posicion x,y del siguiente vertice
            x = diametro*(float)sin(angulo);
            z = diametro*(float)cos(angulo);

           // Especifica el siguiente vertice para el triangulo fan
           glVertex3f(x, -altura/2.0f, z);
           }

        glVertex3f(diametro*(float)sin(2.0f*3.1415f), -altura/2.0f,
                                    diametro*(float)cos(2.0f*3.1415f));
    glEnd();
}

// Crea la rosca para la espiral

void rosca(void)
{
    float x,y,z,angulo;                 // Calcula las coordenadas y el paso del angulo
    float altura = 75.0f;              // altura de la rosca
    float diametro = 20.0f;            // diametro de la rosca
    GLTVector3 vNormal, vCorners[4];   // Almacenamiento para la normal y esquinas
    float paso = (3.1415f/32.0f);      // una revolucion
    float revoluciones = 7.0f;         // Cuantas veces alrededor de la barra
    float ranchura = 2.0f;             // que tan amplia es la rosca
    float respeso = 3.0f;              // que tan espesa es la rosca
    float zpaso = .125f;               // las veces que la rosca se mueve en el eje z
                                       // cada vez que un nuevo segmento se dibuja

    // fija el color del material
    glColor3f(0.7f, 0.7f, 0.7f);
    z = -altura/2.0f+2.0f;

    for(angulo = 0.0f; angulo < GLT_PI * 2.0f *revoluciones; angulo += paso)
        {
        // Calcula la posicion x,y del siguiente vertice
        x = diametro*(float)sin(angulo);
        y = diametro*(float)cos(angulo);

        // almacena el siguiente vertice despues de la barra
        vCorners[0][0] = x;
        vCorners[0][1] = y;
        vCorners[0][2] = z;

        // Calcula la posicion lejos de la barra
        x = (diametro+ranchura)*(float)sin(angulo);
        y = (diametro+ranchura)*(float)cos(angulo);

        vCorners[1][0] = x;
        vCorners[1][1] = y;
        vCorners[1][2] = z;

        // Calcula la siguiente posicion lejos de la barra
        x = (diametro+ranchura)*(float)sin(angulo+paso);
        y = (diametro+ranchura)*(float)cos(angulo+paso);

        vCorners[2][0] = x;
        vCorners[2][1] = y;
        vCorners[2][2] = z + zpaso;

        // Calcula la siguiente posicion a lo largo de la barra
        x = (diametro)*(float)sin(angulo+paso);
        y = (diametro)*(float)cos(angulo+paso);

        vCorners[3][0] = x;
        vCorners[3][1] = y;
        vCorners[3][2] = z+ zpaso;

       glFrontFace(GL_CCW);
       glBegin(GL_TRIANGLES);
           // Calcula la normal para este segmento
           gltGetNormalVector(vCorners[0], vCorners[1], vCorners[2], vNormal);
           glNormal3fv(vNormal);

           // Dibuja 2 triangulos para cubrir el area
           glVertex3fv(vCorners[0]);
           glVertex3fv(vCorners[1]);
           glVertex3fv(vCorners[2]);

           glVertex3fv(vCorners[2]);
           glVertex3fv(vCorners[3]);
           glVertex3fv(vCorners[0]);
        glEnd();

        // Mueve el borde a lo largo de la barra ligeramente en el eje z
        // para representar la parte superior de la anchura
        vCorners[0][2] += respeso;
        vCorners[3][2] += respeso;

        // Recalcula la normal cuando los puntos cambian, esta vez
        // los puntos en la direccion opuesta
        gltGetNormalVector(vCorners[0], vCorners[1], vCorners[2], vNormal);

        vNormal[0] = -vNormal[0];
        vNormal[1] = -vNormal[1];
        vNormal[2] = -vNormal[2];

        glFrontFace(GL_CW);

        // Dibuja los dos triangulos
        glBegin(GL_TRIANGLES);
            glNormal3fv(vNormal);

            glVertex3fv(vCorners[0]);
            glVertex3fv(vCorners[1]);
            glVertex3fv(vCorners[2]);

            glVertex3fv(vCorners[2]);
            glVertex3fv(vCorners[3]);
            glVertex3fv(vCorners[0]);
        glEnd();

        z += zpaso;
        }
}

// dibuja el tornillo
void tornillo(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);

    glPushMatrix();
	glTranslatef(xTrans,yTrans,zTrans);

    glRotatef(xRot, 1.0f, 0.0f, 0.0f);
    glRotatef(yRot, 0.0f, 0.0f, 1.0f);

    barra();
    glPushMatrix();
    glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
    rosca();
    glTranslatef(0.0f,0.0f,45.0f);
    cabeza();
    glPopMatrix();
    glPopMatrix();

    // Swap buffers
    glutSwapBuffers();
}

void teclas(int key, int x, int y){
	if(key == GLUT_KEY_UP)
		xRot -= 10;
	if(key == GLUT_KEY_DOWN)
		xRot += 10;
	if(key == GLUT_KEY_LEFT)
		yRot -= 10;
	if(key == GLUT_KEY_RIGHT)
		yRot += 10;

	xRot = (GLfloat)((const int)xRot % 360);
	yRot = (GLfloat)((const int)yRot % 360);

	glutPostRedisplay();
}

void luces(){
	GLfloat luzBlanca [] = {0.05,0.05,0.05,1.0};
	GLfloat fuenteLuz [] = {0.25,0.25,0.25,1.0};
	GLfloat posicion_Luz[] = {25.f, 50.f, 50.f, 1.f};
	GLfloat v_ambient [] = {0.329412,0.223529,0.027451,1.0};
	GLfloat v_diffuse [] = {0.780392,0.568627,0.113725,1.0};
	GLfloat v_specular [] = {0.992157,0.941176,0.807843,1.0};
	GLfloat v_shininess [] = {27.8974,0,0,0};

	glEnable(GL_DEPTH_TEST);
	glFrontFace(GL_CCW);
	glEnable(GL_CULL_FACE);
	glEnable(GL_LIGHTING);

	glLightModelfv(GL_LIGHT_MODEL_AMBIENT,luzBlanca);
	glLightfv(GL_LIGHT0,GL_AMBIENT,fuenteLuz);
	glLightfv(GL_LIGHT0,GL_DIFFUSE,fuenteLuz);
	glLightfv(GL_LIGHT0,GL_POSITION,posicion_Luz);

	glEnable(GL_LIGHT0);
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT,GL_AMBIENT_AND_DIFFUSE);
	glMaterialfv(GL_FRONT,GL_AMBIENT,v_ambient);
	glMaterialfv(GL_FRONT,GL_DIFFUSE,v_diffuse);
	glMaterialfv(GL_FRONT,GL_SPECULAR,v_specular);
	glMaterialfv(GL_FRONT,GL_SHININESS,v_shininess);
	glClearColor(0.25,0.23,0.50,1.0);
}

main(int argc,char *argv[]){
	glutInit(&argc,argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	glutInitWindowSize(770,525);
	glutCreateWindow("Tornillo");
	glutReshapeFunc(cambia);
	glutSpecialFunc(teclas);
	glutDisplayFunc(tornillo);
	luces();
	glutMainLoop();

	return 0;
}
