//JUAN CARLOS CONDE RAMÍREZ
//OBJETOS 3D COMPLEJOS + CAMARA + MATERIALES
#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <stdio.h>

	//Matriz de colores
	float colores[4][3]=
	{
	    	{1.0,1.0,1.0}, //0 blanco
		{1.0,0.0,0.0}, //1 rojo
		{0.0,1.0,0.0}, //2 verde
		{0.0,0.0,1.0}, //3 azul
	};

	//variables globales para la rotación
	float alpha=45, beta=45;

	//variables globales para la cámara
	float eyeX=0.0f, eyeY=0.0f, eyeZ=5.0f;
	float oriX=0.0f, oriY=1.0f, oriZ=0.0f;

	//Opciones para el menu

	typedef enum{ VSOLID, VWIRE, FRONTAL, TRASERA, LATIZQ, LATDER, SUPERIOR, INFERIOR, MBRONCE, MCHROME, MGOLD, MEMERALD, MRUBY }opcVista;

    //variables globales para el cálculo de los grados
	int x0, y0, opc = 1;

	//MODO DE VISTA
	int vistaSolida = 1;

void luzAmbiental(void)
{
	GLfloat l_difusa[]={0.5f, 0.5f, 0.5f, 0.0f};
	GLfloat l_especular[]={0.5f, 0.5f, 0.5f, 0.0f};
	GLfloat l_posicion[]={1.0, 1.0, 1.0, 0.0};

	GLfloat l_ambiente[]={1.0f, 1.0f, 1.0f, 1.0f};

    	glLightfv(GL_LIGHT0, GL_AMBIENT, l_ambiente);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, l_difusa);
	glLightfv(GL_LIGHT0, GL_POSITION, l_posicion);
	glLightfv(GL_LIGHT0, GL_SPECULAR, l_especular);

	glEnable (GL_LIGHT0);
}

void bronce()
{
	GLfloat l_difusa[]={0.714f, 0.4248f, 0.18144f, 1.0f};
	GLfloat l_especular[]={0.393548f, 0.271906f, 0.166721f, 1.0f};
	GLfloat brillo[]={32.0f};

	GLfloat l_ambiente[]={0.2125f, 0.1275f, 0.054f, 1.0f};
	glMaterialfv(GL_FRONT, GL_AMBIENT, l_ambiente);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, l_difusa);
	glMaterialfv(GL_FRONT, GL_SPECULAR, l_especular);
	glMaterialfv(GL_FRONT, GL_SHININESS, brillo);
}

void chrome()
{
	GLfloat l_difusa[]={0.4f, 0.4f, 0.4f, 1.0f};
	GLfloat l_especular[]={0.774597f, 0.774597f, 0.774597f, 1.0f};
	GLfloat brillo[]={32.0f};

	GLfloat l_ambiente[]={0.25f, 0.25f, 0.25f, 1.0f};
	glMaterialfv(GL_FRONT, GL_AMBIENT, l_ambiente);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, l_difusa);
	glMaterialfv(GL_FRONT, GL_SPECULAR, l_especular);
	glMaterialfv(GL_FRONT, GL_SHININESS, brillo);
}

void gold()
{
	GLfloat l_difusa[]={0.75164f, 0.60648f, 0.22648f, 1.0f};
	GLfloat l_especular[]={0.628281f, 0.555802f, 0.366065f, 1.0f};
	GLfloat brillo[]={32.0f};

	GLfloat l_ambiente[]={0.24725f, 0.1995f, 0.0745f, 1.0f};
	glMaterialfv(GL_FRONT, GL_AMBIENT, l_ambiente);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, l_difusa);
	glMaterialfv(GL_FRONT, GL_SPECULAR, l_especular);
	glMaterialfv(GL_FRONT, GL_SHININESS, brillo);
}


void emerald()
{
	GLfloat l_difusa[]={0.07568f, 0.61424f, 0.07568f, 0.55f};
	GLfloat l_especular[]={0.633f, 0.727811f, 0.633f, 0.55f};
	GLfloat brillo[]={32.0f};

	GLfloat l_ambiente[]={0.0215f, 0.1745f, 0.0215f, 0.55f};
	glMaterialfv(GL_FRONT, GL_AMBIENT, l_ambiente);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, l_difusa);
	glMaterialfv(GL_FRONT, GL_SPECULAR, l_especular);
	glMaterialfv(GL_FRONT, GL_SHININESS, brillo);
}

void ruby()
{
	GLfloat l_difusa[]={0.61424f, 0.04136f, 0.04136f, 0.55f};
	GLfloat l_especular[]={0.727811f, 0.626959f, 0.626059f, 0.55f};
	GLfloat brillo[]={32.0f};

	GLfloat l_ambiente[]={0.1745f, 0.01175f, 0.01175f, 0.55f};
	glMaterialfv(GL_FRONT, GL_AMBIENT, l_ambiente);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, l_difusa);
	glMaterialfv(GL_FRONT, GL_SPECULAR, l_especular);
	glMaterialfv(GL_FRONT, GL_SHININESS, brillo);
}

void init(void)
{
	luzAmbiental();
	glEnable(GL_LIGHTING);
    	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
}

void display1(void)
{
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(20.0f, 1.0f, 1.0f, 10.0f);
	gluLookAt(eyeX, eyeY, eyeZ,
		  0.0f, 0.0f, 0.0f,
		  oriX, oriY, oriZ);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glPushMatrix();
	glColor3f(1.0f, 1.0f, 1.0f);
	
	switch(opc)
	{
		case 1:
			bronce();
			break;			
		case 2:
			chrome();
			break;
			
		case 3:
			gold();
			break;
			
		case 4:
			emerald();
			break;			
		case 5:
			ruby();
			break;			
	}

	if(vistaSolida == 1){
        	glutSolidTeapot(0.5);
	}else {
        	glutWireTeapot(0.5);
	}
	glPopMatrix();

	glFlush();
	glutSwapBuffers();
}

void display2(void)
{
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(20.0f, 1.0f, 1.0f, 10.0f);
	gluLookAt(0.0f, 0.0f, 5.0f,
			  0.0f, 0.0f, 0.0f,
			  0.0f, 1.0f, 0.0f);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glPushMatrix();
		glRotatef(alpha, 1.0f, 0.0f, 0.0f);
		glRotatef(beta, 0.0f, 1.0f, 0.0f);
		glColor3f(1.0f, 1.0f, 1.0f);

	switch(opc)
	{
		case 1:
			bronce();
			break;			
		case 2:
			chrome();
			break;
			
		case 3:
			gold();
			break;
			
		case 4:
			emerald();
			break;			
		case 5:
			ruby();
			break;			
	}
	if(vistaSolida == 1){
        	glutSolidTeapot(0.5);
	}else {
        	glutWireTeapot(0.5);
	}
	glPopMatrix();

	glFlush();
	glutSwapBuffers();
}

//Accion del mouse
void onMouse(int button, int state, int x, int y)
{
	if ( (button == GLUT_LEFT_BUTTON) & (state == GLUT_DOWN) )
	{
		x0 = x;
		y0 = y;
	}
}

//Incremento o decremente de los angulos de rotacion
void onMotion(int x, int y)
{
	alpha = (alpha + (y - y0));
	beta = (beta + (x - x0));
	x0 = x; y0 = y;
	glutPostRedisplay();
}

void onMenu(int opcion){ 
	switch(opcion){
		case VSOLID:
			     vistaSolida = 1;
			     break;

		case VWIRE:
			    vistaSolida = 0;
			     break;

		case FRONTAL:
			     eyeX=0.0f, eyeY=0.0f, eyeZ=5.0f;
			     oriX=0.0f, oriY=1.0f, oriZ=0.0f;
			     break;

		case TRASERA:
			     eyeX=0.0f, eyeY=0.0f, eyeZ=-5.0f;
			     oriX=0.0f, oriY=1.0f, oriZ=0.0f;
			     break;

		case LATIZQ:
			     eyeX=-5.0f, eyeY=0.0f, eyeZ=0.0f;
			     oriX=0.0f, oriY=1.0f, oriZ=0.0f;
			     break;

		case LATDER:
			     eyeX=5.0f, eyeY=0.0f, eyeZ=0.0f;
			     oriX=0.0f, oriY=1.0f, oriZ=0.0f;
			     break;

		case SUPERIOR:
			     eyeX=0.0f, eyeY=5.0f, eyeZ=0.0f;
			     oriX=1.0f, oriY=0.0f, oriZ=0.0f;
			     break;

		case INFERIOR:
			     eyeX=0.0f, eyeY=-5.0f, eyeZ=0.0f;
			     oriX=1.0f, oriY=-0.0f, oriZ=0.0f;
			     break;


		case MBRONCE:
			     opc = 1;
			     break;
		case MCHROME:
			     opc = 2;
			     break;
		case MGOLD:
			     opc = 3;
			     break;
		case MEMERALD:
			     opc = 4;
			     break;
		case MRUBY:
			     opc = 5;
			     break;

	}

	glutPostRedisplay();
}

void creaMenu(){
	int menuPrincipal, submenuVista, submenuMateriales;

	 
	submenuMateriales =  glutCreateMenu(onMenu);
	glutAddMenuEntry("Bronce", MBRONCE);
	glutAddMenuEntry("Chrome", MCHROME);
	glutAddMenuEntry("Gold", MGOLD);
	glutAddMenuEntry("Emerald", MEMERALD);
	glutAddMenuEntry("Ruby", MRUBY);

	submenuVista =  glutCreateMenu(onMenu);
	glutAddMenuEntry("Frontal", FRONTAL);
	glutAddMenuEntry("Trasera", TRASERA);
	glutAddMenuEntry("Lateral izquierda", LATIZQ);
	glutAddMenuEntry("Lateral derecha", LATDER);
	glutAddMenuEntry("Superior", SUPERIOR);
	glutAddMenuEntry("Inferior", INFERIOR);


        //Menu PRINCIPAL
        menuPrincipal = glutCreateMenu(onMenu);
        glutAddMenuEntry("Modo Solido", VSOLID);
        glutAddMenuEntry("Modo Alambre", VWIRE);
        glutAddSubMenu("Material", submenuMateriales);
	glutAddSubMenu("Vista", submenuVista);
	

        glutAttachMenu(GLUT_RIGHT_BUTTON);
}

int main(int argc, char *argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("NAVE 3D: Vista Ortogonal");
	init();
	creaMenu();	
	glutDisplayFunc(display1);

	glutInitWindowSize(500, 500);
	glutInitWindowPosition(615, 100);
	glutCreateWindow("NAVE 3D: Vista en Perspectiva");
	init();
	creaMenu();	

	glutDisplayFunc(display2);
	glutMouseFunc(onMouse);
	glutMotionFunc(onMotion);

	glutMainLoop();

	return 0;
}
