#ifndef MYMATH_H
#include <math.h>
#define MYMATH_H

//matriz de operaciones
double matriz[4][4];

//vector de resultados
double resultante[4];

//Definir las funciones de multiplicar matrices
double[] glMulMatrix( double vertices[4] );
void establecerRotacion( double angulo );
void establecerTraslacion( double nx, double ny);
void establecerEscalamiento( double porcentaje );

#endif
