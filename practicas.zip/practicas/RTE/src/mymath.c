#include "../include/mymath.h"

//Definir las funciones de multiplicar matrices

void establecerRotacion( double angulo ){
	int i, j;
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4 ; j++){
			
		}
	}
}
void establecerTraslacion( double nx, double ny);
void establecerEscalamiento( double porcentaje );

double[] glMulMatrix( double vertices[4] ){
}
