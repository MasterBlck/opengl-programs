#include <stdio.h>
#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#define  ESCALA 50

//Variables de iluminacion
GLfloat luz_difusa  [] = {0.0, 0.0, 1.0, 1.0};
GLfloat luz_especular [] = {0.8, 0.8, 0.1, 1.0};
GLfloat luz_ambiental [] = {50};

//Variables globales para rotacion
float alpha, beta;
int x0, y0;

//Variables globales para las transformaciones
float xpos=0, ypos=0, inc=0.5;

void dibujar();
void inicializar();
void pintarEjes();
void pintarPlano();
void iluminar();

//Eventos del mouse
void onRaton(int boton, int estado, int x, int y);
void onMovimiento(int x, int y);

int main(int argc, char *argv[]){

	glutInit(&argc, argv);
	glutInitWindowSize(1024, 750);
	glutInitWindowPosition(10,10);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Ejemplos basicos");

	inicializar();
	glutDisplayFunc(dibujar);

	glutMouseFunc(onRaton);
        glutMotionFunc(onMovimiento);	

	glutMainLoop();
	return 0;
}

void inicializar(){
	iluminar();

        glMatrixMode( GL_PROJECTION );
        glOrtho(-ESCALA, ESCALA, -ESCALA, ESCALA, -ESCALA, ESCALA);
        glMatrixMode(GL_MODELVIEW);
	glClearColor(0.0, 0.0, 0.0, 0.0);  //combinación (R, G, B, 0.0)        
	//gluOrtho2D(-ESCALA, ESCALA, -ESCALA, ESCALA);  // Se le indica la escala de coordenadas que se quiere trabajar (x1, x2, y1, y2)
        glLoadIdentity();
}

void dibujar(){
	int x_fig, y_fig;
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
/*
	gluPerspective(20.0f, 1.0f, 1.0f, 10.0f);
        gluLookAt(0.0f, 0.0f, 5.0f,
                          0.0f, 0.0f, 0.0f,
                          0.0f, 1.0f, 0.0f);
*/	
	//Dibuja una tetera
        //glColor3f(0.5882, 0.5882, 0.6156);
        glColor3f(0, 1, 0);
	glPushMatrix();
		glRotatef(alpha, 1.0f, 0.0f, 0.0f);
                glRotatef(beta, 0.0f, 1.0f, 0.0f);
	
		glutSolidTeapot(10);
	
		pintarPlano();
		pintarEjes();
	glPopMatrix();


	glFlush();
	glutSwapBuffers();
}


void pintarEjes(){
	
        //linea de X
        glColor3f(1.0, 0.0, 0.0);
        glBegin(GL_LINES);
                glVertex3i(-ESCALA, 0, 0);
                glVertex3i(ESCALA, 0, 0);
        glEnd();

	//linea de Y	
        glColor3f(0.0, 1.0, 0.0);
        glBegin(GL_LINES);
                glVertex3i(0, ESCALA, 0);
                glVertex3i(0, -ESCALA, 0);
        glEnd();

        //linea de Z
        glColor3f(0.0, 0.0, 1.0);
        glBegin(GL_LINES);
                glVertex3i(0, 0, ESCALA);
                glVertex3i(0, 0, -ESCALA);
        glEnd();
}

void pintarPlano(){
	int i;
	
        glColor3f(0.2901, 0.2901, 0.2901);
	for(i = -ESCALA; i <= ESCALA; i=i+5){

		//pinta las filas
		glBegin(GL_LINES);
			glVertex3i(-ESCALA, i, 0);
			glVertex3i(ESCALA, i, 0);
		glEnd();

		//pinta las columnas
		glBegin(GL_LINES);
			glVertex3i(i, -ESCALA, 0);
			glVertex3i(i, ESCALA, 0);
		glEnd();
	}

}

void onRaton(int boton, int estado, int x, int y){
	if ( (boton == GLUT_LEFT_BUTTON) & (estado == GLUT_DOWN) )
        {
                x0 = x;
                y0 = y;
        }

}

void onMovimiento(int x, int y){
	alpha = (alpha + (y - y0));
        beta = (beta + (x - x0));
        x0 = x; y0 = y;
        glutPostRedisplay();
}

void iluminar(){
	GLfloat light_position[]  = {1.0, 1.0, 1.0, 0.0};

        glLightfv(GL_LIGHT0, GL_POSITION, light_position);

        glMaterialfv(GL_FRONT, GL_DIFFUSE, luz_difusa);
        glMaterialfv(GL_FRONT, GL_SPECULAR, luz_especular);
        glMaterialfv(GL_FRONT, GL_SHININESS, luz_ambiental);

        glEnable(GL_LIGHTING);
        glEnable(GL_LIGHT0);
        glEnable(GL_DEPTH_TEST);
        glDepthFunc(GL_LEQUAL);
}
