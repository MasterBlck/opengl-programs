#include <stdio.h>
#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#define  ESCALA 50

void dibujar();
void inicializar();

int main(int argc, char *argv[]){

	glutInit(&argc, argv);
	glutInitWindowSize(1024, 750);
	glutInitWindowPosition(10,10);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Ejemplos basicos");

	inicializar();
	glutDisplayFunc(dibujar);
	glutMainLoop();
	return 0;
}

void inicializar(){
	glMatrixMode( GL_PROJECTION );
	gluOrtho2D(-ESCALA, ESCALA, -ESCALA, ESCALA);  // Se le indica la escala de coordenadas que se quiere trabajar (x1, x2, y1, y2)
	glClearColor(0.0, 0.0, 0.0, 0.0);  //combinación (R, G, B, 0.0)
}

void dibujar(){
	glClear( GL_COLOR_BUFFER_BIT );

	// Figura con GL_POINTS	
	glPointSize(4.0);
	glColor3f(1.0, 1.0, 1.0);
	x_fig = -45; y_fig = 35;
	glBegin(GL_POINTS);
		glVertex2f(x_fig, y_fig);
		glVertex2f(x_fig + 10, y_fig);
		glVertex2f(x_fig + 12, y_fig + 5);
		glVertex2f(x_fig + 10, y_fig + 10);
		glVertex2f(x_fig, y_fig + 10);
		glVertex2f(x_fig - 2, y_fig + 5);
	glEnd();
	
	//Figura con GL_LINES
	glColor3f(0.0, 1.0, 1.0);    // (R, G, B)
	x_fig = -25;
	glBegin(GL_LINES);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)

		glVertex2i(x_fig + 12, y_fig + 5);	
		glVertex2i(x_fig + 10, y_fig + 10);
	
		glVertex2i(x_fig, y_fig + 10);	
		glVertex2i(x_fig -2, y_fig + 5);	
	glEnd();

	


	//dibuja los ejes
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
		glVertex2i(0, ESCALA);
		glVertex2i(0, -ESCALA);
		glVertex2i(-ESCALA, 0);
		glVertex2i(ESCALA, 0);
	glEnd();


	glFlush();
	glutSwapBuffers();
}
