#include <stdio.h>
#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#define  ESCALA 50

void dibujar();
void inicializar();
void animar();

GLfloat rotEsfera = 0.0;

int main(int argc, char *argv[]){

	glutInit(&argc, argv);
	glutInitWindowSize(1024, 750);
	glutInitWindowPosition(10,10);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Ejemplos basicos");

	inicializar();
	glutDisplayFunc(dibujar);

	//NUEVO: para redibujar la pantalla constantemente
	glutIdleFunc(animar);

	glutMainLoop();
	return 0;
}

void inicializar(){
	glMatrixMode( GL_PROJECTION );
	//Podemos usar en caso de trabajar en 3D
	glOrtho(-ESCALA, ESCALA, -ESCALA, ESCALA, -ESCALA, ESCALA);
	glMatrixMode(GL_MODELVIEW);
	

	/*gluOrtho2D(-ESCALA, ESCALA, -ESCALA, ESCALA);  // Se le indica la escala de coordenadas que se quiere trabajar (x1, x2, y1, y2)
	glClearColor(0.0, 0.0, 0.0, 0.0);  //combinación (R, G, B, 0.0)*/

	//usarlo para las operaciones de transformacion:
	glLoadIdentity();
}

void dibujar(){
	glClear( GL_COLOR_BUFFER_BIT );
	int x_fig, y_fig;

	// Figura con GL_POINTS	
	glPointSize(4.0);
	glColor3f(1.0, 1.0, 1.0);
	x_fig = -45; y_fig = 35;
	glBegin(GL_POINTS);
		glVertex2f(x_fig, y_fig);
		glVertex2f(x_fig + 10, y_fig);
		glVertex2f(x_fig + 12, y_fig + 5);
		glVertex2f(x_fig + 10, y_fig + 10);
		glVertex2f(x_fig, y_fig + 10);
		glVertex2f(x_fig - 2, y_fig + 5);
	glEnd();
	
	//Figura con GL_LINES
	x_fig = -25;
	glColor3f(0.0, 1.0, 1.0);    // (R, G, B)
	glBegin(GL_LINES);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)

		glVertex2i(x_fig + 12, y_fig + 5);	
		glVertex2i(x_fig + 10, y_fig + 10);
	
		glVertex2i(x_fig, y_fig + 10);	
		glVertex2i(x_fig -2, y_fig + 5);	
	glEnd();
	
	//dibuja un cubo
	glPushMatrix();
	glTranslatef(10, 10, 0);
	glRotated(25, 0, 0, 1);
	glRotated(42, 1, 0, 0);
	glRotated(25, 0, 1, 0);
	glScaled(1.5, 1.5, 1.5);
	glutWireCube(5);
	glPopMatrix();

	//Dibuja una esfera
	glColor3f(0.0, 0.0, 1.0);    // (R, G, B)
	glPushMatrix();
	glTranslatef(-10, -15, 0);
	glRotated(rotEsfera, 0, 0, 1);
	glRotated(70, 1, 0, 0);
	glRotated(0, 0, 1, 0);
	glScaled(0.5, 0.5, 1);
	glutWireSphere(10, 30, 30);
	glPopMatrix();	

	//Dibuja un triangulo
	glColor3f(0.0, 1.0, 0.0);    // (R, G, B)
	x_fig = 5; y_fig = 1;
	glPushMatrix();			//Ponemos la matriz en la pila para traslado
	glTranslatef(-5, -15, 0);
	glBegin(GL_TRIANGLES);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)
		glVertex2i(x_fig, y_fig + 15);	
	glEnd();
	glPopMatrix();			//Sacamos la matriz una vez usada

	//dibuja los ejes
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
		glVertex3i(0, ESCALA, 0);
		glVertex3i(0, -ESCALA, 0);
		glVertex3i(-ESCALA, 0, 0);
		glVertex3i(ESCALA, 0, 0);
	glEnd();

	//dibuja los ejes Z
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_LINES);
		glVertex3i(0, 0, ESCALA);
		glVertex3i(0, 0, -ESCALA);
	glEnd();

	//quitar glFlush en caso de animar()
//	glFlush();
	glutSwapBuffers();
}

void animar(){
	rotEsfera = rotEsfera + 5;
	
	glutPostRedisplay();
}
