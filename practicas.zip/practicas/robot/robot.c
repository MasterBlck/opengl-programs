#include <stdio.h>
#include <string.h>
#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#include <math.h>
#define  ESCALA 20

typedef enum { 
		F_BANCO = 311,
		F_NEGRO = 312,
		F_ROJO = 313,
		F_ROJO_CLARO = 314,
		F_VERDE = 315,
		F_VERDE_OSCURO = 316,
		F_AZUL = 317,
		F_AZUL_CLARO = 318  
	} TE_opcionesMenuColoresFondo;

typedef enum { 
		O_BANCO = 321,
		O_NEGRO = 322,
		O_ROJO = 323,
		O_ROJO_CLARO = 324,
		O_VERDE = 325,
		O_VERDE_OSCURO = 326,
		O_AZUL = 327,
		O_AZUL_CLARO = 328  
	} TE_opcionesMenuColoresObjeto;

char *partesRobot[] = {
			 "Cabeza",
			 "Cuadro",  
			 "Cuerpo",  
			 "Brazo izquierdo",  
			 "Brazo derecho",
			 "Pierna izquierda",  
			 "Pierna derecha"  
		    };

char *coloresParaMenu[] = {
			"0 - blanco",
			"1 - negro",
			"2 - rojo",
			"3 - rojo claro",
			"4 - verde",
			"5 - verde oscuro",
			"6 - azul",
			"7 - azul claro"
		  };

struct coordenadas{
	GLfloat x, y, z;
};

typedef struct coordenadas T_COORDENADAS;

char modo[3];
int sky = 0, fig = 0;

void dibujar();
void inicializar();

//pastes del cuerpo
void cabeza();
void cuadro();
void cuerpo();
void brazo();
void pierna();
void pintarEjes();

//Controles del teclado
void controlTeclado(unsigned char tecla, int x, int y);

//Control del mouse
void onRaton(int boton, int estado, int x, int y);
void onMovimiento(GLsizei x, GLsizei y);

//Creacion del menu
void creaMenu();
void onMenu(int opcion);
void menuColoresFondo(int opc);
void menuColoresObjeto(int opc);

T_COORDENADAS nuevaCoordenada(GLfloat x, GLfloat y, GLfloat z);
//-------------------------------------------------------------------------separar----------------------------------------------------
float colores[8][3] =
{
	{ 1.00f, 1.00f, 1.00f}, // 0 - blanco
	{ 0.00f, 0.00f, 0.00f}, // 1 - negro
	{ 1.00f, 0.00f, 0.00f}, // 2 - rojo
	{ 0.50f, 0.26f, 0.12f}, // 3 - rojo claro
	{ 0.00f, 1.00f, 0.00f}, // 4 - verde
	{ 0.06f, 0.25f, 0.13f}, // 5 - verde oscuro
	{ 0.00f, 0.00f, 1.00f}, // 6 - azul
	{ 0.85f, 0.95f, 1.00f}, // 7 - azul claro
};

//------------------------------------------------------------------------------------------------------------------------------------
//Variables globales para traslado, rotacion, escalado
T_COORDENADAS traslado = {0, 0, 0},
	      rotacion = {0, 0, 0},
	      escalamiento = {0, 0, 0}; 

int main(int argc, char *argv[]){
	// validar que los argumentos que ponga el usuario sean validos
	if(argc <= 1 || (strcmp(argv[1], "-T") != 0 && strcmp(argv[1], "-P") != 0)){
		printf("Modo de uso:");
		printf("\n\t.\\robot <opcion>");
		printf("\n\tOpciones:\n\t\t-T\tDibuja con triangulos\n\t\t-P\tDibuja con poligonos\n");
		exit(1);
	}

	//De acuerdo a la entrada de usuario, sera el modo en que se dibuje el robot	
	strcpy(modo, argv[1]);
	printf("%s\n", modo);

	glutInit(&argc, argv);
	glutInitWindowSize(1024, 750);
	glutInitWindowPosition(10,10);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Robot de Lorenzo Lamas (Poligonos)");
	inicializar();
	creaMenu();

	//funcion para el manejo de las teclas
	glutKeyboardFunc(controlTeclado);

	//funcion para el control del mouse
	glutMouseFunc(onRaton);
	glutMotionFunc(onMovimiento);

	glutDisplayFunc(dibujar);
	glutMainLoop();
	return 0;
}

void inicializar(){
	glMatrixMode( GL_PROJECTION );
	glOrtho(-ESCALA, ESCALA, -ESCALA, ESCALA, -ESCALA, ESCALA);
	glMatrixMode(GL_MODELVIEW);
	//gluOrtho2D(-ESCALA, ESCALA, -ESCALA, ESCALA);  // Se le indica la escala de coordenadas que se quiere trabajar (x1, x2, y1, y2)
	glLoadIdentity();
}

void dibujar(){
	glClearColor(colores[sky][0], colores[sky][1], colores[sky][2], 0.0);  //combinación (R, G, B, 0.0)
	glClear( GL_COLOR_BUFFER_BIT );

	//cabeza
	glPushMatrix();                 //Ponemos la matriz en la pila para traslado	
	//primero se rota el objeto (solo con respecto al eje Z)
	glRotated(0.0, 0, 0, 1);
	//en segundo lugar se traslada
	//glTranslatef(-2, 11, 0);
	glTranslatef(traslado.x, traslado.y, traslado.z);
	//en ultimo lugar escalamos
	glScaled(1.0, 1.0, 1.0);
	cabeza();
	glPopMatrix();

	//cuadro
	glPushMatrix();                 	
	glRotated(0.0, 0, 0, 1);
	glTranslatef(0, 0, 0);
	glScaled(1.0, 1.0, 1.0);
	cuadro();
	glPopMatrix();

	//cuerpo
	glPushMatrix();                 	
	glRotated(0.0, 0, 0, 1);
	glTranslatef(-2, 6, 0);
	glScaled(1.0, 1.0, 1.0);
	cuerpo();
	glPopMatrix();

	//brazo derecho
	glPushMatrix();                 	
	//glRotated(0.0, 0, 0, 1);
	glRotated(rotacion.x, 1, 0, 0);
	glRotated(rotacion.y, 0, 1, 0);
	glRotated(rotacion.z, 0, 0, 1);
	glTranslatef(2, 6, 0);
	//glScaled(1.0, 1.0, 1.0);
	glScaled(escalamiento.x, escalamiento.y, 1.0);
	glColor3f(colores[fig][0], colores[fig][1], colores[fig][2]);
	brazo();
	pintarEjes();
	glPopMatrix();
	
	//brazo izquierdo
	glPushMatrix();                 	
	glRotated(180.0, 0, 0, 1);
	glTranslatef(2, -4, 0);
	glScaled(1.0, 1.0, 1.0);
	brazo();
	glPopMatrix();

	//pierna derecha
	glPushMatrix();                 	
	glRotated(0.0, 0, 0, 1);
	glTranslatef(-2, -1, 0);
	glScaled(1.0, 1.0, 1.0);
	pierna();
	glPopMatrix();

	//pierna izquierda
	glPushMatrix();                 	
	glRotated(180.0, 0, 1, 0);
	glTranslatef(-2, -1, 0);
	glScaled(1.0, 1.0, 1.0);
	pierna();
	glPopMatrix();
	
	//pintarEjes();

	glFlush();
	glutSwapBuffers();
}


void cabeza(){
	T_COORDENADAS punto = nuevaCoordenada(0, 0, 0);
	//ojos y boca
	glPointSize(4.0);	
	//glColor3f(0.2352, 0.2823, 0.3372);
	glColor3f(0.0, 0.0, 0.0);
	glFrontFace(GL_CCW);   
	glBegin(GL_POINTS);
		glVertex2f(punto.x + 1.5, punto.y - 1);
		glVertex2f(punto.x + 2.5, punto.y - 1);
	glEnd();

	
	glBegin(GL_LINES);
		glVertex2f(punto.x + 1.5, punto.y - 1);
		glVertex2f(punto.x + 2.5, punto.y - 1);
		glVertex2f(punto.x + 1.5, punto.y - 1.5);
		glVertex2f(punto.x + 2.5, punto.y - 1.5);
	glEnd();
//--------------------------------------------------------------------------------------------------------

	glFrontFace(GL_CW);	//dibujaremos en sentido horario

	if(strcmp(modo, "-P") == 0){	//Dibujar en modo poligonal

		//Dibuja la cabeza del robot
		glColor3f(0.953, 0.9059, 0.8510);
		//dibuja la cara
		glBegin(GL_QUADS);
			glVertex2f(punto.x, punto.y);
			glVertex2f(punto.x + 4, punto.y);
			glVertex2f(punto.x + 4, punto.y -3.5);
			glVertex2f(punto.x, punto.y - 3.5);
		glEnd();

		//Dibuja la oreja derecha
		glColor3f(0.2352, 0.2823, 0.3372);
		glBegin(GL_QUADS);
			glVertex2f(punto.x + 4, punto.y - 1);
			glVertex2f(punto.x + 4.5, punto.y - 1);
			glVertex2f(punto.x + 4.5, punto.y - 2.5);
			glVertex2f(punto.x + 4, punto.y - 2.5);
		glEnd();

		//Dibuja la antena derecha
		glColor3f(0.953, 0.9059, 0.8510);
		glBegin(GL_LINE_STRIP);
			glVertex2f(punto.x + 5.5, punto.y - 1);
			glVertex2f(punto.x + 5.5, punto.y - 1.5);
			glVertex2f(punto.x + 4.5, punto.y - 1.5);
		glEnd();


		//Dibuja la oreja izquierda
		glColor3f(0.2352, 0.2823, 0.3372);
		glBegin(GL_QUADS);
			glVertex2f(punto.x - 0.5, punto.y - 1);
			glVertex2f(punto.x, punto.y - 1);
			glVertex2f(punto.x, punto.y - 2.5);
			glVertex2f(punto.x - 0.5, punto.y - 2.5);
		glEnd();

		//Dibuja la antena izquierda
		glColor3f(0.953, 0.9059, 0.8510);
		glBegin(GL_LINE_STRIP);
			glVertex2f(punto.x - 0.5, punto.y - 1.5);
			glVertex2f(punto.x - 1.5, punto.y - 1.5);
			glVertex2f(punto.x - 1.5, punto.y - 1);
		glEnd();

		//Dibuja el cuello
		glColor3f(0.8980, 0.3529, 0.2784);
		glBegin(GL_QUADS);
			glVertex2f(punto.x + 1.5, punto.y - 3.5);
			glVertex2f(punto.x + 2.5, punto.y - 3.5);
			glVertex2f(punto.x + 2.5, punto.y - 5);
			glVertex2f(punto.x + 1.5, punto.y - 5);
		glEnd();
	} else {			//Modo de triangulos
	
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);	
		//Dibuja la cabeza del robot
		glColor3f(0.953, 0.9059, 0.8510);
		//dibuja la cara
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x, punto.y);
			glVertex2f(punto.x + 4, punto.y);
			glVertex2f(punto.x, punto.y -3.5);

			glVertex2f(punto.x + 4, punto.y);
			glVertex2f(punto.x + 4, punto.y - 3.5);
			glVertex2f(punto.x, punto.y - 3.5);
		glEnd();

		//Dibuja la oreja derecha
		glColor3f(0.2352, 0.2823, 0.3372);
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 4, punto.y - 1);
			glVertex2f(punto.x + 4.5, punto.y - 1);
			glVertex2f(punto.x + 4, punto.y - 2.5);

			glVertex2f(punto.x + 4.5, punto.y - 1);
			glVertex2f(punto.x + 4.5, punto.y - 2.5);
			glVertex2f(punto.x + 4, punto.y - 2.5);
		glEnd();

		//Dibuja la antena derecha
		glColor3f(0.953, 0.9059, 0.8510);
		glBegin(GL_LINE_STRIP);
			glVertex2f(punto.x + 5.5, punto.y - 1);
			glVertex2f(punto.x + 5.5, punto.y - 1.5);
			glVertex2f(punto.x + 4.5, punto.y - 1.5);
		glEnd();


		//Dibuja la oreja izquierda
		glColor3f(0.2352, 0.2823, 0.3372);
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x - 0.5, punto.y - 1);
			glVertex2f(punto.x, punto.y - 1);
			glVertex2f(punto.x, punto.y - 2.5);

			glVertex2f(punto.x, punto.y - 2.5);
			glVertex2f(punto.x - 0.5, punto.y - 2.5);
			glVertex2f(punto.x - 0.5, punto.y - 1);
		glEnd();

		//Dibuja la antena izquierda
		glColor3f(0.953, 0.9059, 0.8510);
		glBegin(GL_LINE_STRIP);
			glVertex2f(punto.x - 0.5, punto.y - 1.5);
			glVertex2f(punto.x - 1.5, punto.y - 1.5);
			glVertex2f(punto.x - 1.5, punto.y - 1);
		glEnd();

		//Dibuja el cuello
		glColor3f(0.8980, 0.3529, 0.2784);
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 1.5, punto.y - 3.5);
			glVertex2f(punto.x + 2.5, punto.y - 3.5);
			glVertex2f(punto.x + 2.5, punto.y - 5);

			glVertex2f(punto.x + 2.5, punto.y - 5);
			glVertex2f(punto.x + 1.5, punto.y - 5);
			glVertex2f(punto.x + 1.5, punto.y - 3.5);
		glEnd();
	}
	
}


void cuadro(){

	T_COORDENADAS punto = nuevaCoordenada(0, 0, 0);
	//Dibuja el cuadro desde el centro
	glColor3f(0.8980, 0.3529, 0.2784);

	glFrontFace(GL_CW);	//dibujaremos en sentido horario
	if(strcmp(modo, "-P") == 0){	//Dibujar en modo poligonal

		glBegin(GL_QUADS);
			glVertex2f(punto.x - 2, punto.y + 1);
			glVertex2f(punto.x + 2, punto.y + 1); 
			glVertex2f(punto.x + 2, punto.y - 1);
			glVertex2f(punto.x - 2, punto.y - 1);
		glEnd();

	} else {

		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x - 2, punto.y + 1);
			glVertex2f(punto.x + 2, punto.y + 1); 
			glVertex2f(punto.x + 2, punto.y - 1);

			glVertex2f(punto.x + 2, punto.y - 1);
			glVertex2f(punto.x - 2, punto.y - 1);
			glVertex2f(punto.x - 2, punto.y + 1);
		glEnd();
	}
	

}

void cuerpo(){

	T_COORDENADAS punto = nuevaCoordenada(0, 0, 0);
	//Dibuja el cuadro desde el centro
	glColor3f(0.953, 0.9059, 0.8510);
	
	glFrontFace(GL_CW);	//dibujaremos en sentido horario
	if(strcmp(modo, "-P") == 0){	//Dibujar en modo poligonal
		//Dibuja el cuerpo 
		glBegin(GL_POLYGON);
			glVertex2f(punto.x, punto.y);
			glVertex2f(punto.x + 4, punto.y); 
			glVertex2f(punto.x + 4, punto.y - 3);
			glVertex2f(punto.x + 3, punto.y - 5);
			glVertex2f(punto.x + 1, punto.y - 5);
			glVertex2f(punto.x, punto.y - 3);
		glEnd();
	} else {

		//Dibuja el cuerpo 
		glBegin(GL_TRIANGLE_FAN);
			glVertex2f(punto.x + 4, punto.y - 3);
			glVertex2f(punto.x + 3, punto.y - 5); 
			glVertex2f(punto.x + 1, punto.y - 5);
			glVertex2f(punto.x, punto.y - 3);
			glVertex2f(punto.x, punto.y);
			glVertex2f(punto.x + 4, punto.y);
		glEnd();
	}
}

void brazo(){
	
	T_COORDENADAS punto = nuevaCoordenada(0, 0, 0);

	if(strcmp(modo, "-P") == 0){	//Dibujar en modo poligonal
		//Dibuja in brazo hacia arriba
	//	glColor3f(0.9921, 0.8, 0.2980);
		glFrontFace(GL_CW);	//dibujaremos en sentido horario
		glBegin(GL_QUADS);
			glVertex2f(punto.x, punto.y);
			glVertex2f(punto.x + 1, punto.y); 
			glVertex2f(punto.x + 1, punto.y - 2);
			glVertex2f(punto.x, punto.y - 2);
		glEnd();

		
	//	glColor3f(0.2352, 0.2823, 0.3372);
		glBegin(GL_QUADS);
			glVertex2f(punto.x + 1 , punto.y - 0.5);
			glVertex2f(punto.x + 4, punto.y - 0.5); 
			glVertex2f(punto.x + 4, punto.y - 1.5);
			glVertex2f(punto.x + 1, punto.y - 1.5);
		glEnd();

		
	//	glColor3f(0.8980, 0.3529, 0.2784);
		glFrontFace(GL_CCW);	//dibujaremos en entido antihorario
		glBegin(GL_QUADS);
			glVertex2f(punto.x + 3 , punto.y - 0.5);
			glVertex2f(punto.x + 4, punto.y - 0.5); 
			glVertex2f(punto.x + 4, punto.y + 2);
			glVertex2f(punto.x + 3, punto.y + 2);
		glEnd();


	//	glColor3f(0.2352, 0.2823, 0.3372);
		glFrontFace(GL_CCW);	//dibujaremos en entido antihorario
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 3 , punto.y + 2);
			glVertex2f(punto.x + 4, punto.y + 2); 
			glVertex2f(punto.x + 3, punto.y + 3);
		glEnd();


		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 3 , punto.y + 2);
			glVertex2f(punto.x + 4, punto.y + 2); 
			glVertex2f(punto.x + 4, punto.y + 3);
		glEnd();
	} else {

		//Dibuja in brazo hacia arriba
	//	glColor3f(0.9921, 0.8, 0.2980);
		glFrontFace(GL_CW);	//dibujaremos en sentido horario
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x, punto.y);
			glVertex2f(punto.x + 1, punto.y); 
			glVertex2f(punto.x + 1, punto.y - 2);

			glVertex2f(punto.x + 1, punto.y - 2);
			glVertex2f(punto.x, punto.y - 2);
			glVertex2f(punto.x, punto.y);
		glEnd();

		
	//	glColor3f(0.2352, 0.2823, 0.3372);
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 1 , punto.y - 0.5);
			glVertex2f(punto.x + 4, punto.y - 0.5); 
			glVertex2f(punto.x + 4, punto.y - 1.5);

			glVertex2f(punto.x + 4, punto.y - 1.5);
			glVertex2f(punto.x + 1, punto.y - 1.5);
			glVertex2f(punto.x + 1 , punto.y - 0.5);
		glEnd();

		
	//	glColor3f(0.8980, 0.3529, 0.2784);
		glFrontFace(GL_CCW);	//dibujaremos en entido antihorario
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 3 , punto.y - 0.5);
			glVertex2f(punto.x + 4, punto.y - 0.5); 
			glVertex2f(punto.x + 4, punto.y + 2);

			glVertex2f(punto.x + 4, punto.y + 2);
			glVertex2f(punto.x + 3, punto.y + 2);
			glVertex2f(punto.x + 3 , punto.y - 0.5);
		glEnd();


	//	glColor3f(0.2352, 0.2823, 0.3372);
		glFrontFace(GL_CCW);	//dibujaremos en entido antihorario
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 3 , punto.y + 2);
			glVertex2f(punto.x + 4, punto.y + 2); 
			glVertex2f(punto.x + 3, punto.y + 3);
		glEnd();


		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 3 , punto.y + 2);
			glVertex2f(punto.x + 4, punto.y + 2); 
			glVertex2f(punto.x + 4, punto.y + 3);
		glEnd();
	}
}

void pierna(){
	
	T_COORDENADAS punto = nuevaCoordenada(0, 0, 0);
	glFrontFace(GL_CW);	//dibujaremos en sentido horario

	if(strcmp(modo, "-P") == 0){	//Dibujar en modo poligonal
		//Dibuja in brazo hacia arriba
		glColor3f(0.9921, 0.8, 0.2980);
		glBegin(GL_QUADS);
			glVertex2f(punto.x, punto.y);
			glVertex2f(punto.x + 1, punto.y); 
			glVertex2f(punto.x + 1, punto.y - 2);
			glVertex2f(punto.x, punto.y - 2);
		glEnd();


		glColor3f(0.1254, 0.6274, 0.4980);
		glBegin(GL_QUADS);
			glVertex2f(punto.x + 0.5, punto.y - 2);
			glVertex2f(punto.x + 1.3, punto.y - 2.5); 
			glVertex2f(punto.x + 0.5, punto.y - 3);
			glVertex2f(punto.x - 0.3, punto.y - 2.5);
		glEnd();


		glColor3f(0.9921, 0.8, 0.2980);
		glBegin(GL_QUADS);
			glVertex2f(punto.x, punto.y - 3);
			glVertex2f(punto.x + 1, punto.y - 3); 
			glVertex2f(punto.x + 1, punto.y - 5);
			glVertex2f(punto.x, punto.y - 5);
		glEnd();


		glColor3f(0.8980, 0.3529, 0.2784);
		glBegin(GL_QUADS);
			glVertex2f(punto.x + 1, punto.y - 5);
			glVertex2f(punto.x + 1, punto.y - 6); 
			glVertex2f(punto.x - 1, punto.y - 6);
			glVertex2f(punto.x - 1, punto.y - 5);
		glEnd();
	} else {
		
		//Dibuja in brazo hacia arriba
		glColor3f(0.9921, 0.8, 0.2980);
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x, punto.y);
			glVertex2f(punto.x + 1, punto.y); 
			glVertex2f(punto.x + 1, punto.y - 2);

			glVertex2f(punto.x + 1, punto.y - 2);
			glVertex2f(punto.x, punto.y - 2);
			glVertex2f(punto.x, punto.y);
		glEnd();


		glColor3f(0.1254, 0.6274, 0.4980);
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 0.5, punto.y - 2);
			glVertex2f(punto.x + 1.3, punto.y - 2.5); 
			glVertex2f(punto.x + 0.5, punto.y - 3);

			glVertex2f(punto.x + 0.5, punto.y - 3);
			glVertex2f(punto.x - 0.3, punto.y - 2.5);
			glVertex2f(punto.x + 0.5, punto.y - 2);
		glEnd();


		glColor3f(0.9921, 0.8, 0.2980);
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x, punto.y - 3);
			glVertex2f(punto.x + 1, punto.y - 3); 
			glVertex2f(punto.x + 1, punto.y - 5);

			glVertex2f(punto.x + 1, punto.y - 5);
			glVertex2f(punto.x, punto.y - 5);
			glVertex2f(punto.x, punto.y - 3);
		glEnd();


		glColor3f(0.8980, 0.3529, 0.2784);
		glBegin(GL_TRIANGLES);
			glVertex2f(punto.x + 1, punto.y - 5);
			glVertex2f(punto.x + 1, punto.y - 6); 
			glVertex2f(punto.x - 1, punto.y - 6);

			glVertex2f(punto.x - 1, punto.y - 6);
			glVertex2f(punto.x - 1, punto.y - 5);
			glVertex2f(punto.x + 1, punto.y - 5);
		glEnd();
	}
}

T_COORDENADAS nuevaCoordenada(GLfloat x, GLfloat y, GLfloat z){
	T_COORDENADAS c = {x, y, z};
	return c;
}

void pintarEjes(){

	//dibuja los ejes
	//linea de Y
	glColor3f(0.0, 1.0, 0.0);
	glBegin(GL_LINES);
		glVertex3i(0, ESCALA, 0);
		glVertex3i(0, -ESCALA, 0);
	glEnd();

	//linea de X
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_LINES);
		glVertex3i(-ESCALA, 0, 0);
		glVertex3i(ESCALA, 0, 0);
	glEnd();

	//linea de Z
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
		glVertex3i(0, 0, ESCALA);
		glVertex3i(0, 0, -ESCALA);
	glEnd();

}


void controlTeclado(unsigned char tecla, int x, int y){
	switch(tecla){
		case 'w':
			traslado.y += 1;
			break;

		case 's':
			traslado.y -= 1;
			break;

		case 'a':
			traslado.x -= 1;
			break;

		case 'd':
			traslado.x += 1;
			break;
	}	
	glutPostRedisplay();
}


void onRaton(int boton, int estado, int x, int y){
	//manejo de Rotacion -> vinculado con el movimiento del mouse
	if(( boton == GLUT_LEFT_BUTTON ) && ( estado == GLUT_DOWN )){
		rotacion.x = x;
		rotacion.y = y;
	}

	//Manejo de escalamiento
	if(( boton == GLUT_LEFT_BUTTON ) && ( estado == GLUT_DOWN )){
		escalamiento.x += 0.5;
		escalamiento.y += 0.5;
	}

	if(( boton == GLUT_RIGHT_BUTTON ) && ( estado == GLUT_DOWN )){
		escalamiento.x -= 0.5;
		escalamiento.y -= 0.5;
	}

	glutPostRedisplay();
}

void onMovimiento(GLsizei x, GLsizei y){
	int alpha, beta;

	//Calcular angulo de rotacion en base a la posicion inicial y final del mouse
	alpha = ( alpha + ( y - rotacion.y) );
	beta = ( beta + ( x - rotacion.x ) );

	//actualizar valor de la ultima coordenada
	rotacion.x = x;
	rotacion.y = y;

	//elegir el angulo mas grande para rotar
	if( abs(alpha) >= abs(beta) ){
		rotacion.z = alpha;
	} else {
		rotacion.z = beta;
	}	

	glutPostRedisplay();
}

void onMenu(int opcion){
	
	switch(opcion){

		case F_BANCO:
			printf("Selecciono Fondo Blanco\n");
			sky = 0;
			break;

		case F_NEGRO:
			printf("Selecciono Fondo Negro\n");
			sky = 1;
			break;

		case F_ROJO:
			printf("Selecciono Fondo Rojo\n");
			sky = 2;
			break;

		case F_ROJO_CLARO:
			printf("Selecciono Fondo Rojo Claro\n");
			sky = 3;
			break;

		case F_VERDE:
			printf("Selecciono Fondo Verde\n");
			sky = 4;
			break;

		case F_VERDE_OSCURO:
			printf("Selecciono Fondo Verde oscuro\n");
			sky = 5;
			break;

		case F_AZUL:
			printf("Selecciono Fondo Azul\n");
			sky = 6;
			break;

		case F_AZUL_CLARO:
			printf("Selecciono Fondo Azul Claro\n");
			sky = 7;
			break;

		case O_BANCO:
		       fig = 0;
		       break;

		case O_NEGRO:
		       fig = 1;
		       break;

		case O_ROJO:
		       fig = 2;
		       break;

		case O_ROJO_CLARO:
		       fig = 3;
		       break;

		case O_VERDE:
		       fig = 4;
		       break;

		case O_VERDE_OSCURO:
		       fig = 5;
		       break;

		case O_AZUL:
		       fig = 6;
		       break;

		case O_AZUL_CLARO:
			fig = 7;
			break;

	}

	glutPostRedisplay();
}

void creaMenu(){
	int menuPrincipal, subMenuTipoColor, o_subMenuColor, f_subMenuColor, i, submenuPartesR, submenuTrans;
	TE_opcionesMenuColoresFondo fc_opciones[] = {
		F_BANCO,
		F_NEGRO,
		F_ROJO,
		F_ROJO_CLARO,
		F_VERDE,
		F_VERDE_OSCURO,
		F_AZUL,
		F_AZUL_CLARO  
	};

	TE_opcionesMenuColoresObjeto oc_opciones[] = {
		O_BANCO,
		O_NEGRO,
		O_ROJO,
		O_ROJO_CLARO,
		O_VERDE,
		O_VERDE_OSCURO,
		O_AZUL,
		O_AZUL_CLARO
	};  
	
	//Submenu de color, para el fondo
	f_subMenuColor = glutCreateMenu(onMenu);
	for(i = 0; i < 8; i++){
		glutAddMenuEntry(coloresParaMenu[i], fc_opciones[i]);
	}

	//Submenu de color, para los objetos
	o_subMenuColor = glutCreateMenu(onMenu);
	for(i = 0; i < 8; i++){
		glutAddMenuEntry(coloresParaMenu[i], oc_opciones[i]);
	}

	//Submenu para partes del cuerpo
	submenuPartesR = glutCreateMenu(onMenu);	
	for(i = 0; i < 7; i++){
		glutAddSubMenu(partesRobot[i], o_subMenuColor);
	}

	//Submenu de tipo de color
	subMenuTipoColor = glutCreateMenu(onMenu);
	glutAddSubMenu("Fondo", f_subMenuColor);
	glutAddSubMenu("Objeto", submenuPartesR);

//--------------------------------------------------------------------------------------------------------------------

	//Submenu para partes del cuerpo
	submenuPartesR = glutCreateMenu(onMenu);	
	for(i = 0; i < 7; i++){
		glutAddMenuEntry(partesRobot[i], i);
	}

	//submenu de transformaciones
	submenuTrans = glutCreateMenu(onMenu);
	glutAddSubMenu("Traslado", submenuPartesR );
	glutAddSubMenu("Rotacion", submenuPartesR );
	glutAddSubMenu("Escalamiento", submenuPartesR );
	

	//Menu PRINCIPAL
	menuPrincipal = glutCreateMenu(onMenu);
	glutAddSubMenu("Control Teclado", submenuTrans);
	glutAddSubMenu("Control Mouse", submenuTrans);
	glutAddSubMenu("Color", subMenuTipoColor);
	glutAttachMenu(GLUT_RIGHT_BUTTON);		
}

void menuColoresFondo(int opc){

}

void menuColoresObjeto(int opc){

}
