#include <stdio.h>
#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>
#define  ESCALA 50

void dibujar();
void dibujarTyC();
void inicializar();

int main(int argc, char *argv[]){

	glutInit(&argc, argv);
	glutInitWindowSize(1024, 750);
	glutInitWindowPosition(10,10);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Ejemplos basicos");

	inicializar();
	glutDisplayFunc(dibujar);
	//glutMainLoop();

	//Se despliega la segunda ventana
	glutInitWindowSize(1024, 750);
	glutInitWindowPosition(10,10);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutCreateWindow("Otra Ventana");

	inicializar();
	glutDisplayFunc(dibujarTyC);

	glutMainLoop();
	return 0;
}

void inicializar(){
	glMatrixMode( GL_PROJECTION );
	gluOrtho2D(-ESCALA, ESCALA, -ESCALA, ESCALA);  // Se le indica la escala de coordenadas que se quiere trabajar (x1, x2, y1, y2)
	glClearColor(0.0, 0.0, 0.0, 0.0);  //combinación (R, G, B, 0.0)
}

void dibujar(){
	glClear( GL_COLOR_BUFFER_BIT );
	int x_fig = 0, y_fig = 0;	

	// Figura con GL_POINTS	
	glPointSize(4.0);
	glColor3f(1.0, 1.0, 1.0);
	x_fig = -45; y_fig = 35;
	glBegin(GL_POINTS);
		glVertex2f(x_fig, y_fig);
		glVertex2f(x_fig + 10, y_fig);
		glVertex2f(x_fig + 12, y_fig + 5);
		glVertex2f(x_fig + 10, y_fig + 10);
		glVertex2f(x_fig, y_fig + 10);
		glVertex2f(x_fig - 2, y_fig + 5);
	glEnd();
	
	//Figura con GL_LINES
	glColor3f(0.0, 1.0, 1.0);    // (R, G, B)
	x_fig = -25;
	glBegin(GL_LINES);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)

		glVertex2i(x_fig + 12, y_fig + 5);	
		glVertex2i(x_fig + 10, y_fig + 10);
	
		glVertex2i(x_fig, y_fig + 10);	
		glVertex2i(x_fig -2, y_fig + 5);	
	glEnd();

	
	//Figura con GL_LINE_STRIP
	glColor3f(1.0, 1.0, 0.0);    // (R, G, B)
	x_fig = 5;
	glBegin(GL_LINE_STRIP);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)

		glVertex2i(x_fig + 12, y_fig + 5);	
		glVertex2i(x_fig + 10, y_fig + 10);
	
		glVertex2i(x_fig, y_fig + 10);	
		glVertex2i(x_fig -2, y_fig + 5);	
	glEnd();
	
	//Figura con GL_LINE_LOOP
	glColor3f(0.0, 0.0, 1.0);    // (R, G, B)
	x_fig = 25;
	glBegin(GL_LINE_LOOP);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)

		glVertex2i(x_fig + 12, y_fig + 5);	
		glVertex2i(x_fig + 10, y_fig + 10);
	
		glVertex2i(x_fig, y_fig + 10);	
		glVertex2i(x_fig -2, y_fig + 5);	
	glEnd();

	//Figura con GL_POLYGON
	glColor3f(1.0, 0.0, 0.0);    // (R, G, B)
	x_fig = -45; y_fig = 20;
	glBegin(GL_POLYGON);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)

		glVertex2i(x_fig + 12, y_fig + 5);	
		glVertex2i(x_fig + 10, y_fig + 10);
	
		glVertex2i(x_fig, y_fig + 10);	
		glVertex2i(x_fig -2, y_fig + 5);	
	glEnd();

	//Figura con GL_TRIANGLES
	glColor3f(0.0, 1.0, 0.0);    // (R, G, B)
	x_fig = -25;
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glBegin(GL_TRIANGLES);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)
		glVertex2i(x_fig + 12, y_fig + 5);
	
		glVertex2i(x_fig + 10, y_fig + 10);	
		glVertex2i(x_fig, y_fig + 10);	
		glVertex2i(x_fig -2, y_fig + 5);	
	glEnd();

	//Figura con GL_TRIANGLE_STRIP
	glColor3f(0.921, 0.047, 0.909);    // (R, G, B)
	x_fig = 30;
	glBegin(GL_TRIANGLE_STRIP);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig - 7, y_fig + 12);	//vertice final(y, x)
		glVertex2i(x_fig - 10, y_fig + 2);
	
		glVertex2i(x_fig - 17, y_fig + 13);	
		glVertex2i(x_fig - 20, y_fig + 2);	
		glVertex2i(x_fig - 25, y_fig + 11);
		glVertex2i(x_fig - 27, y_fig + 1);
	glEnd();

	//Figura con GL_TRIANGLE_FAN
	glColor3f(0.2352, 0.3019, 0.0627);    // (R, G, B)
	x_fig = -45; y_fig = -25;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y).

		glVertex2i(x_fig + 15, y_fig + 7);	//vertice final(y, x)
		glVertex2i(x_fig + 13, y_fig + 9);
		glVertex2i(x_fig + 8, y_fig + 12);	
		glVertex2i(x_fig + 5, y_fig + 14);
	glEnd();	

	//Figura con GL_QUADS
	glColor3f(1.0, 0.141, 0.788);    // (R, G, B)
	x_fig = -8;
	glBegin(GL_QUADS);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 2, y_fig + 7);	//vertice final(y, x)
		glVertex2i(x_fig - 5, y_fig + 9);
		glVertex2i(x_fig - 11, y_fig - 1);
	
		glVertex2i(x_fig - 14, y_fig + 7);	
		glVertex2i(x_fig - 14, y_fig + 20);
		glVertex2i(x_fig - 19, y_fig + 10);
		glVertex2i(x_fig - 21, y_fig + 9);
	glEnd();

	//Figura con GL_QUAD_STRIP
	glColor3f(0.215, 0.235, 0.909);    // (R, G, B)
	x_fig = 25; y_fig = -30;
	glBegin(GL_QUAD_STRIP);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 2, y_fig + 7);	//vertice final(y, x)
		glVertex2i(x_fig - 5, y_fig + 10);
		glVertex2i(x_fig - 11, y_fig - 1);
	
		glVertex2i(x_fig - 14, y_fig + 7);	
		glVertex2i(x_fig - 14, y_fig + 20);
		glVertex2i(x_fig - 19, y_fig + 10);
		glVertex2i(x_fig - 21, y_fig + 9);
	glEnd();

	//dibuja los ejes
	glColor3f(0.0, 0.0, 1.0);
	glBegin(GL_LINES);
		glVertex2i(0, ESCALA);
		glVertex2i(0, -ESCALA);
		glVertex2i(-ESCALA, 0);
		glVertex2i(ESCALA, 0);
	glEnd();


	glFlush();
	glutSwapBuffers();
}

void dibujarTyC(){

	glClear( GL_COLOR_BUFFER_BIT );
	int x_fig = 0, y_fig = 0;

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	//Figura con GL_TRIANGLES
	glColor3f(0.0, 1.0, 0.0);    // (R, G, B)
	x_fig = -25;
	glBegin(GL_TRIANGLES);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 10, y_fig);	//vertice final(y, x)
		glVertex2i(x_fig + 12, y_fig + 5);
	
		glVertex2i(x_fig + 10, y_fig + 10);	
		glVertex2i(x_fig, y_fig + 10);	
		glVertex2i(x_fig -2, y_fig + 5);	
	glEnd();

	//Figura con GL_TRIANGLE_STRIP
	glColor3f(0.921, 0.047, 0.909);    // (R, G, B)
	x_fig = 30;
	glBegin(GL_TRIANGLE_STRIP);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig - 7, y_fig + 12);	//vertice final(y, x)
		glVertex2i(x_fig - 10, y_fig + 2);
	
		glVertex2i(x_fig - 17, y_fig + 13);	
		glVertex2i(x_fig - 20, y_fig + 2);	
		glVertex2i(x_fig - 25, y_fig + 11);
		glVertex2i(x_fig - 27, y_fig + 1);
	glEnd();

	//Figura con GL_TRIANGLE_FAN
	glColor3f(0.2352, 0.3019, 0.0627);    // (R, G, B)
	x_fig = -45; y_fig = -25;
	glBegin(GL_TRIANGLE_FAN);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y).

		glVertex2i(x_fig + 15, y_fig + 7);	//vertice final(y, x)
		glVertex2i(x_fig + 13, y_fig + 9);
		glVertex2i(x_fig + 8, y_fig + 12);	
		glVertex2i(x_fig + 5, y_fig + 14);
	glEnd();	

	//Figura con GL_QUADS
	glColor3f(1.0, 0.141, 0.788);    // (R, G, B)
	x_fig = -8;
	glBegin(GL_QUADS);
		glVertex2i(x_fig, y_fig);	//vertice de inicio(x, y)
		glVertex2i(x_fig + 2, y_fig + 7);	//vertice final(y, x)
		glVertex2i(x_fig - 5, y_fig + 9);
		glVertex2i(x_fig - 11, y_fig - 1);
	
		glVertex2i(x_fig - 14, y_fig + 7);	
		glVertex2i(x_fig - 14, y_fig + 20);
		glVertex2i(x_fig - 19, y_fig + 10);
		glVertex2i(x_fig - 21, y_fig + 9);
	glEnd();

	//Figura con GL_QUAD_STRIP
	glFlush();
	glutSwapBuffers();
}
