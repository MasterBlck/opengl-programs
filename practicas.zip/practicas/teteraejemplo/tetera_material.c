#include <GL/freeglut.h>
#include <GL/glx.h>
#include <GL/gl.h>

void init(void)
{
 // Ubicamos la fuente de luz en el punto (1.0, 1.0, 1.0)
 GLfloat light_position[] = { 1.0, 1.0, 1.0, 0.0 };

 // Activamos la fuente de luz
 glEnable(GL_LIGHTING);
 glEnable(GL_LIGHT0);
 glDepthFunc(GL_LESS);
 glEnable(GL_DEPTH_TEST);
 glShadeModel(GL_SMOOTH);
 // Queremos que se dibujen las caras frontales
 // y con un color solido de relleno.
 glPolygonMode(GL_FRONT, GL_FILL);
}

void reshape(int w, int h)
{
 if (!h)
	return;
 glViewport(0, 0,  (GLsizei) w, (GLsizei) h);
 // Activamos la matriz de proyeccion.
 glMatrixMode(GL_PROJECTION);
 // "limpiamos" esta con la matriz identidad.
 glLoadIdentity();
 // Usamos proyeccion ortogonal
  glOrtho(-200, 200, -200, 200, -200, 200);
 // Activamos la matriz de modelado/visionado.
 glMatrixMode(GL_MODELVIEW);
 // "Limpiamos" la matriz
 glLoadIdentity();
}

// Aqui ponemos lo que queremos dibujar.
void display(void)
{
 // Propiedades del material
 GLfloat mat_ambient[] = { 0.24725f, 0.1995f, 0.0745f, 1.0f };
 GLfloat mat_diffuse[] = { 0.75164f, 0.60648f, 0.22648f, 1.0f };
 GLfloat mat_specular[] = { 0.628281f, 0.555802f, 0.366065f, 1.0f };
 GLfloat mat_shininess[] = { 51.2f };

 // "Limpiamos" el frame buffer con el color de "Clear", en este
 // caso negro.
 glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

 glMatrixMode( GL_MODELVIEW_MATRIX );
 glLoadIdentity();

 // Rotacion de 30 grados en torno al eje x
 glRotated(25.0, 1.0, 0.0, 0.0);
 // Rotacion de -30 grados en torno al eje y
 glRotated(-30.0, 0.0, 1.0, 0.0);
 // Dibujamos una "Tetera" y le aplico el material

 glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
 glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
 glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
 glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
 glutSolidTeapot(125.0);

 glFlush();
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize (300, 300);
    glutInitWindowPosition (0, 0);
	glutCreateWindow ("Teapot");
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutMainLoop();

	return 0;
}
